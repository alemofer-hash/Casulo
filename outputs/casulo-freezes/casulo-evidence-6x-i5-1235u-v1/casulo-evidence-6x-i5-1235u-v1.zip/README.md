# Casulo

Casulo é um invento original da **Teloscorp** para **Otimização de Tráfego de
Informação**.

Ele recebe uma fonte integral, reconhece sua estrutura, mede o atrito da
travessia, escolhe um tratamento, reorganiza o conteúdo sem descarte silencioso
e libera uma **Borboleta**: a informação completa, mais navegável, enriquecida
e acompanhada por prova de conservação.

## A evolução

```text
Ovo
  → Larva
    → Crisálida
      → Metamorfose
        → Borboleta
```

- **Ovo**: fonte original, imutável e identificada por hash.
- **Larva**: conteúdo ingerido, inventariado e perfilado.
- **Crisálida**: decisão e plano de tratamento.
- **Metamorfose**: reorganização conservativa e enriquecimentos.
- **Borboleta**: pacote integral otimizado e verificável.

O **Casulo** é o orquestrador de todas as fases.

## Lei do invento

Todo conteúdo recebido precisa aparecer:

1. no conteúdo integral reorganizado; ou
2. na quarentena, com motivo explícito.

O contador `descartes_silenciosos` precisa ser sempre zero.

## Uso Python

```python
from casulo import Casulo

borboleta = Casulo().evoluir(
    "entrada.csv",
    destino="saida-casulo",
)

print(borboleta.prova_conservacao)
```

## Linha de comando

```powershell
python -m casulo entrada.csv --destino saida-casulo
```

Um perfil opcional em JSON pode definir campos esperados, aliases, campo
temporal e volume de referência:

```json
{
  "nome": "operacao",
  "campos_esperados": ["timestamp", "origem", "valor"],
  "aliases": {
    "data_hora": "timestamp"
  },
  "campo_temporal": "timestamp",
  "volume_referencia_bytes": 100000
}
```

```powershell
python -m casulo entrada.csv --destino saida --perfil perfil.json
```

## Pacote liberado

```text
saida/
├─ 00_ovo/
│  └─ fonte_original.*
├─ 01_larva/
│  └─ inventario.json
├─ 02_crisalida/
│  └─ plano_de_evolucao.json
├─ 03_metamorfose/
│  ├─ conteudo_integral.jsonl
│  ├─ quarentena.jsonl
│  └─ enriquecimentos.json
├─ 04_borboleta/
│  ├─ indice.json
│  └─ prova_de_conservacao.json
├─ MARCA_E_AUTORIA.txt
└─ manifesto.json
```

## Formatos iniciais

- CSV/TSV e outros delimitadores comuns;
- JSON;
- texto linha a linha;
- XLSX quando `openpyxl` estiver instalado.

Formatos não compreendidos continuam fisicamente preservados no Ovo e são
liberados na quarentena, nunca descartados.

## Validação

```powershell
python -m unittest discover -s tests -v
```

## Linguagem T — fase Borboleta

O compilador aberto da linguagem T agora vive no próprio repositório, sem
depender de um backend escondido em executável.

```powershell
python -m pip install -e .
t doctor
t check examples/t/balanco_hidrico.t
t inspect examples/t/balanco_hidrico.t
t inspect examples/t/balanco_hidrico.t --symbols
t inspect examples/t/balanco_hidrico.t --ir
t inspect examples/t/balanco_hidrico.t --graph
t build examples/t/balanco_hidrico.t --output build/balanco
t build examples/t/balanco_hidrico.t --output build/balanco --native
t run build/balanco --input examples/t/hydrocell.json
t run build/balanco --input benchmarks/data/water-balance-f64.json --native
t run build/balanco --input examples/t/hydrocell_batch.json --batch
t run build/balanco --input examples/t/hydrocell_batch.json --adaptive
t benchmark build/balanco --input examples/t/hydrocell_batch.json --repeat 1000
t native-benchmark build/balanco --input benchmarks/data/water-balance-f64.json --repeat 2000
t simd-benchmark build/balanco --input benchmarks/data/water-balance-f64.json --repeat 2000
t experiment examples/t/balanco_hidrico.t --output build/borboleta
```

O compilador aberto contém:

- `OvoLexer`: linhas, comentários, indentação e localização;
- `OvoParser`: AST do núcleo T 1.0;
- `LarvaAnalyzer`: primeiro gate semântico;
- tabela de símbolos com escopos;
- inferência e verificação de tipos;
- análise de emissão em todos os caminhos;
- `CrisálidaIR`: representação intermediária textual e JSON;
- backend Python de referência autocontido;
- grafo def-use da Metamorfose;
- classificação de determinismo, efeitos e custo;
- kernel de lote fundido;
- memoização por operação e deduplicação dentro do lote;
- benchmark escalar versus lote com prova de equivalência;
- laboratório Borboleta com dataset determinístico e amostras brutas;
- intervalo de confiança por bootstrap e ordem de execução alternada;
- telemetria de tempo, CPU, memória e energia elétrica detectável;
- relatório científico JSON e HTML autocontido;
- seletor adaptativo com perfil Larva e decisão Crisálida;
- escolha auditável entre recalcular e deduplicar;
- orçamento explícito de memória para cache;
- artefato reproduzível com fonte, IR, executável e manifesto;
- cache endereçado por conteúdo;
- executor com validação da entrada e da integridade do artefato;
- chave estrutural tipada especializada por operação;
- cache intralote com colisão verificada e vida útil explícita;
- buffers colunares `float64`/`int64` com evidência lateral;
- manifestação tardia com fallback conservativo para objetos;
- ABI `casulo-native-abi/0.1` com layout colunar `float64`;
- backend `c99-simd/0.3`, compilação AOT e DLL/SO endereçada por conteúdo;
- remoção de código morto e propagação segura de constantes e aliases;
- arena colunar reutilizável com capacidade em potência de dois;
- validação e marshal fundidos e especializados por esquema;
- manifestação de fronteira especializada por operação;
- benchmark com marshal, kernel e manifestação medidos separadamente;
- IC95% pareado do ganho por bootstrap;
- separação conservativa entre fase de guardas e laço numérico;
- perfil escalar estrito de controle e perfil SIMD específico da máquina;
- relatório de vetorização preservado na proveniência da build;
- fallback Python explícito para tipo, forma ou compilador incompatível;
- prova de equivalência Python escalar versus C99 nativo;
- diagnósticos estruturados, com código e posição;
- corpus golden de conformidade;
- `t check`, `t inspect`, `t build`, `t run`, `t benchmark`,
  `t native-benchmark`, `t simd-benchmark`, `t experiment` e `t doctor`.

O envelope de execução preserva integralmente a entrada, manifesta o resultado
e registra julgamentos, restrições, projeções, vínculos e estabilizações.

```text
build/balanco/
├─ source.t
├─ crisalida.ir.json
├─ metamorfose.graph.json
├─ casulo_artifact.py
├─ casulo_native.c
├─ casulo_native.abi.json
└─ manifest.json
```

O módulo gerado usa apenas a biblioteca padrão do Python e pode ser executado
fora da IDE. A fonte C99 também é portátil; o binário nativo é um derivado
reproduzível por plataforma e compilador, armazenado fora do artefato assinado.

O núcleo continua sem dependências obrigatórias. Para instalar o laboratório
científico e as ferramentas de desenvolvimento:

```console
python -m pip install -e ".[science,dev]"
```

A Borboleta chama energia de joules somente quando encontra um contador
elétrico cumulativo. Na ausência dele, publica `not_measured` e conserva tempo
de CPU apenas como proxy de trabalho computacional.

A especificação está em [docs/t-spec-1.0.md](docs/t-spec-1.0.md).
A IR está documentada em
[docs/crisalida-ir-0.1.md](docs/crisalida-ir-0.1.md).
O artefato está documentado em
[docs/python-backend-0.4.md](docs/python-backend-0.4.md).
O protocolo de buffers está em
[docs/typed-buffer-0.1.md](docs/typed-buffer-0.1.md).
A ABI nativa está em
[docs/native-abi-0.1.md](docs/native-abi-0.1.md).
O AOT e a arena estão em
[docs/aot-arena-0.1.md](docs/aot-arena-0.1.md).
O perfil SIMD está em
[docs/simd-0.1.md](docs/simd-0.1.md).
O grafo está documentado em
[docs/metamorfose-graph-0.1.md](docs/metamorfose-graph-0.1.md).
O protocolo de desempenho está em
[docs/benchmark-metamorfose-0.1.md](docs/benchmark-metamorfose-0.1.md).
O protocolo Borboleta está em
[docs/borboleta-protocol-0.4.md](docs/borboleta-protocol-0.4.md).
O seletor adaptativo está em
[docs/adaptive-cost-model-0.3.md](docs/adaptive-cost-model-0.3.md).
O fechamento do Marco 3 está em
[docs/sprints/010-aot-arena-marco3.md](docs/sprints/010-aot-arena-marco3.md).

## Demonstração congelada do marco 6×

O resultado ponta a ponta do Sprint 011 foi preservado como uma evidência
visual, autocontida e auditável:

- [demonstração para compradores](evidence/2026-07-30-marco4-6x/index.html);
- [protocolo e limites da evidência](evidence/2026-07-30-marco4-6x/README.md);
- [preparação comercial e de proteção intelectual](docs/commercial-and-ip-readiness.md).

A alegação congelada é `6,095936×` de ganho mediano pareado, com IC95% de
`5,994133×–6,230838×`, no experimento e hardware declarados. Ela não é uma
promessa universal de desempenho.

## Casulo e Teloscorp

**Casulo** é o invento. **Teloscorp** é sua autoria e origem pública.

O nome Teloscorp combina *télos* — finalidade — com *corp*, de corporação:
todo dado tem um fim para ser usado. A lembrança de uma corporação de histórias
em quadrinhos é intencional e integra a personalidade da marca.

Veja [NOTICE.md](NOTICE.md) para a atribuição que deve acompanhar distribuições
e derivados.

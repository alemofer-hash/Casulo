field Sample
  value: Number

condense Empty

condense Broken
  while true

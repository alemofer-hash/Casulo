from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .analyzer import AnalysisResult, expression_key
from .ast import (
    BindStmt,
    CondenseDecl,
    EmitStmt,
    FieldDecl,
    IfStmt,
    JudgeStmt,
    LetStmt,
    Program,
    ProjectStmt,
    RestrictStmt,
    StabilizeStmt,
    Statement,
    TransitionDecl,
)
from .diagnostics import SourceSpan


IR_VERSION = "crisalida-ir/0.1"


@dataclass(frozen=True, slots=True)
class IRTrace:
    name: str
    type_name: str


@dataclass(frozen=True, slots=True)
class IRField:
    name: str
    traces: tuple[IRTrace, ...]


@dataclass(frozen=True, slots=True)
class IRInstruction:
    op: str
    arguments: tuple[str, ...] = ()
    result: str | None = None
    type_name: str | None = None
    then_body: tuple["IRInstruction", ...] = ()
    else_body: tuple["IRInstruction", ...] = ()
    span: SourceSpan | None = None


@dataclass(frozen=True, slots=True)
class IROperation:
    kind: str
    name: str
    input_type: str | None
    target_type: str | None
    output_type: str
    instructions: tuple[IRInstruction, ...]


@dataclass(frozen=True, slots=True)
class IRProgram:
    version: str
    module: str | None
    uses: tuple[str, ...]
    fields: tuple[IRField, ...]
    operations: tuple[IROperation, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def render_text(self) -> str:
        lines = [self.version]
        if self.module:
            lines.append(f"module {self.module}")
        for use in self.uses:
            lines.append(f"use {use}")
        if self.module or self.uses:
            lines.append("")

        for field_decl in self.fields:
            lines.append(f"field {field_decl.name} {{")
            for trace in field_decl.traces:
                lines.append(f"  {trace.name}: {trace.type_name}")
            lines.append("}")
            lines.append("")

        for operation in self.operations:
            if operation.kind == "transition":
                signature = (
                    f"transition {operation.name}("
                    f"{operation.input_type} -> {operation.target_type}"
                    f") -> {operation.output_type}"
                )
            else:
                input_rendered = operation.input_type or "-"
                signature = (
                    f"condense {operation.name}("
                    f"{input_rendered}) -> {operation.output_type}"
                )
            lines.append(signature + " {")
            lines.extend(_render_instructions(operation.instructions, 1))
            lines.append("}")
            lines.append("")
        return "\n".join(lines).rstrip() + "\n"


class CrisalidaLowerer:
    def lower(self, program: Program, analysis: AnalysisResult) -> IRProgram:
        fields: list[IRField] = []
        operations: list[IROperation] = []

        for declaration in program.declarations:
            if isinstance(declaration, FieldDecl):
                fields.append(
                    IRField(
                        name=declaration.name,
                        traces=tuple(
                            IRTrace(
                                name=trace.name,
                                type_name=_render_type_ref(trace.type_ref),
                            )
                            for trace in declaration.traces
                        ),
                    )
                )
            elif isinstance(declaration, CondenseDecl):
                operations.append(
                    IROperation(
                        kind="condense",
                        name=declaration.name,
                        input_type=declaration.input_type,
                        target_type=None,
                        output_type=analysis.operation_outputs[
                            declaration.name
                        ].render(),
                        instructions=self._lower_block(
                            declaration.body,
                            analysis,
                        ),
                    )
                )
            elif isinstance(declaration, TransitionDecl):
                operations.append(
                    IROperation(
                        kind="transition",
                        name=declaration.name,
                        input_type=declaration.from_type,
                        target_type=declaration.to_type,
                        output_type=analysis.operation_outputs[
                            declaration.name
                        ].render(),
                        instructions=self._lower_block(
                            declaration.body,
                            analysis,
                        ),
                    )
                )

        return IRProgram(
            version=IR_VERSION,
            module=program.module.name if program.module else None,
            uses=tuple(use.name for use in program.uses),
            fields=tuple(fields),
            operations=tuple(operations),
        )

    def _lower_block(
        self,
        body: tuple[Statement, ...],
        analysis: AnalysisResult,
    ) -> tuple[IRInstruction, ...]:
        return tuple(
            self._lower_statement(statement, analysis)
            for statement in body
        )

    def _lower_statement(
        self,
        statement: Statement,
        analysis: AnalysisResult,
    ) -> IRInstruction:
        if isinstance(statement, LetStmt):
            return IRInstruction(
                op="let",
                result=statement.name,
                arguments=(statement.value.text,),
                type_name=self._expression_type(statement.value, analysis),
                span=statement.span,
            )
        if isinstance(statement, JudgeStmt):
            return IRInstruction(
                op="judge",
                arguments=(statement.condition.text,),
                type_name="Bool",
                span=statement.span,
            )
        if isinstance(statement, RestrictStmt):
            return IRInstruction(
                op="restrict",
                arguments=(statement.condition.text,),
                type_name="Bool",
                span=statement.span,
            )
        if isinstance(statement, StabilizeStmt):
            return IRInstruction(
                op="stabilize",
                arguments=(statement.target.text,),
                type_name=self._expression_type(statement.target, analysis),
                span=statement.span,
            )
        if isinstance(statement, EmitStmt):
            return IRInstruction(
                op="emit",
                arguments=(statement.value.text,),
                type_name=self._expression_type(statement.value, analysis),
                span=statement.span,
            )
        if isinstance(statement, ProjectStmt):
            arguments = [statement.source.text]
            if statement.target:
                arguments.append(f"as:{statement.target}")
            if statement.into:
                arguments.append("into:" + ",".join(statement.into))
            return IRInstruction(
                op="project",
                arguments=tuple(arguments),
                type_name=self._expression_type(statement.source, analysis),
                span=statement.span,
            )
        if isinstance(statement, BindStmt):
            return IRInstruction(
                op="bind",
                arguments=(statement.left.text, statement.right.text),
                span=statement.span,
            )
        if isinstance(statement, IfStmt):
            return IRInstruction(
                op="if",
                arguments=(statement.condition.text,),
                type_name="Bool",
                then_body=self._lower_block(statement.then_body, analysis),
                else_body=self._lower_block(statement.else_body, analysis),
                span=statement.span,
            )
        raise TypeError(f"unsupported statement: {type(statement)!r}")

    @staticmethod
    def _expression_type(expression, analysis: AnalysisResult) -> str:
        inferred = analysis.expression_types.get(expression_key(expression))
        return inferred.render() if inferred is not None else "Any"


def _render_type_ref(type_ref) -> str:
    value = type_ref.name
    for _ in range(type_ref.list_depth):
        value = f"[{value}]"
    if type_ref.optional:
        value += "?"
    return value


def _render_instructions(
    instructions: tuple[IRInstruction, ...],
    depth: int,
) -> list[str]:
    prefix = "  " * depth
    lines: list[str] = []
    for instruction in instructions:
        if instruction.op == "if":
            lines.append(
                f"{prefix}if {instruction.arguments[0]} : Bool {{"
            )
            lines.extend(_render_instructions(instruction.then_body, depth + 1))
            lines.append(f"{prefix}}}")
            if instruction.else_body:
                lines.append(f"{prefix}else {{")
                lines.extend(
                    _render_instructions(instruction.else_body, depth + 1)
                )
                lines.append(f"{prefix}}}")
            continue
        rendered_args = ", ".join(instruction.arguments)
        rendered_type = (
            f" : {instruction.type_name}"
            if instruction.type_name
            else ""
        )
        if instruction.result:
            lines.append(
                f"{prefix}%{instruction.result} = "
                f"{instruction.op} {rendered_args}{rendered_type}"
            )
        else:
            lines.append(
                f"{prefix}{instruction.op} {rendered_args}{rendered_type}"
            )
    return lines

from __future__ import annotations

import ast
from dataclasses import asdict, dataclass
from typing import Any

from .ir import IRInstruction, IROperation, IRProgram
from .typesys import translate_literals


GRAPH_VERSION = "metamorfose-graph/0.1"
_BUILTINS = frozenset({"abs", "round", "sqrt", "len", "min", "max"})


@dataclass(frozen=True, slots=True)
class GraphNode:
    id: str
    operation: str
    path: str
    kind: str
    label: str
    defines: tuple[str, ...]
    uses: tuple[str, ...]
    pure: bool
    effect: str
    estimated_cost: int


@dataclass(frozen=True, slots=True)
class GraphEdge:
    source: str
    target: str
    kind: str
    name: str | None = None


@dataclass(frozen=True, slots=True)
class OperationGraph:
    name: str
    input_type: str | None
    output_type: str
    deterministic: bool
    cacheable: bool
    estimated_cost: int
    effects: tuple[str, ...]
    nodes: tuple[GraphNode, ...]
    edges: tuple[GraphEdge, ...]


@dataclass(frozen=True, slots=True)
class MetamorfoseGraph:
    version: str
    module: str | None
    operations: tuple[OperationGraph, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def render_text(self) -> str:
        lines = [self.version]
        if self.module:
            lines.append(f"module {self.module}")
        if self.module:
            lines.append("")
        for operation in self.operations:
            effects = ",".join(operation.effects) or "-"
            lines.append(
                f"operation {operation.name} "
                f"cacheable={str(operation.cacheable).lower()} "
                f"cost={operation.estimated_cost} "
                f"effects={effects}"
            )
            for node in operation.nodes:
                defines = ",".join(node.defines) or "-"
                uses = ",".join(node.uses) or "-"
                lines.append(
                    f"  node {node.id} kind={node.kind} "
                    f"defines={defines} uses={uses} "
                    f"effect={node.effect} cost={node.estimated_cost}"
                )
            for edge in operation.edges:
                label = f" name={edge.name}" if edge.name else ""
                lines.append(
                    f"  edge {edge.source} -> {edge.target} "
                    f"kind={edge.kind}{label}"
                )
            lines.append("")
        return "\n".join(lines).rstrip() + "\n"


class MetamorfoseGraphBuilder:
    def build(self, program: IRProgram) -> MetamorfoseGraph:
        fields = {
            field.name: tuple(trace.name for trace in field.traces)
            for field in program.fields
        }
        operations = tuple(
            self._build_operation(operation, fields)
            for operation in program.operations
        )
        return MetamorfoseGraph(
            version=GRAPH_VERSION,
            module=program.module,
            operations=operations,
        )

    def _build_operation(
        self,
        operation: IROperation,
        fields: dict[str, tuple[str, ...]],
    ) -> OperationGraph:
        nodes: list[GraphNode] = []
        edges: list[GraphEdge] = []
        definitions: dict[str, str] = {}
        for trace in fields.get(operation.input_type or "", ()):
            node_id = f"{operation.name}/input/{trace}"
            nodes.append(
                GraphNode(
                    id=node_id,
                    operation=operation.name,
                    path=f"input.{trace}",
                    kind="input",
                    label=trace,
                    defines=(trace,),
                    uses=(),
                    pure=True,
                    effect="read",
                    estimated_cost=0,
                )
            )
            definitions[trace] = node_id

        self._walk_block(
            operation,
            operation.instructions,
            definitions,
            nodes,
            edges,
            prefix="root",
            control_parent=None,
        )
        effects = tuple(
            dict.fromkeys(
                node.effect
                for node in nodes
                if node.effect not in {"pure", "read", "control"}
            )
        )
        return OperationGraph(
            name=operation.name,
            input_type=operation.input_type,
            output_type=operation.output_type,
            deterministic=True,
            cacheable=True,
            estimated_cost=sum(node.estimated_cost for node in nodes),
            effects=effects,
            nodes=tuple(nodes),
            edges=tuple(_deduplicate_edges(edges)),
        )

    def _walk_block(
        self,
        operation: IROperation,
        instructions: tuple[IRInstruction, ...],
        definitions: dict[str, str],
        nodes: list[GraphNode],
        edges: list[GraphEdge],
        prefix: str,
        control_parent: str | None,
    ) -> None:
        for index, instruction in enumerate(instructions):
            path = f"{prefix}.{index}"
            node_id = f"{operation.name}/instruction/{path}/{instruction.op}"
            expressions = _instruction_expressions(instruction)
            profiles = tuple(_expression_profile(item) for item in expressions)
            uses = tuple(
                sorted(
                    {
                        name
                        for profile_names, _ in profiles
                        for name in profile_names
                    }
                )
            )
            defines = (
                (instruction.result,)
                if instruction.op == "let" and instruction.result
                else ()
            )
            effect, pure = _effect_for(instruction.op)
            cost = 1 + sum(profile_cost for _, profile_cost in profiles)
            nodes.append(
                GraphNode(
                    id=node_id,
                    operation=operation.name,
                    path=path,
                    kind=instruction.op,
                    label=_instruction_label(instruction),
                    defines=defines,
                    uses=uses,
                    pure=pure,
                    effect=effect,
                    estimated_cost=cost,
                )
            )
            if control_parent is not None:
                edges.append(
                    GraphEdge(
                        source=control_parent,
                        target=node_id,
                        kind="control",
                    )
                )
            for name in uses:
                source = definitions.get(name)
                if source is not None:
                    edges.append(
                        GraphEdge(
                            source=source,
                            target=node_id,
                            kind="data",
                            name=name,
                        )
                    )
            if defines:
                definitions[defines[0]] = node_id
            if instruction.op == "if":
                self._walk_block(
                    operation,
                    instruction.then_body,
                    definitions.copy(),
                    nodes,
                    edges,
                    prefix=f"{path}.then",
                    control_parent=node_id,
                )
                self._walk_block(
                    operation,
                    instruction.else_body,
                    definitions.copy(),
                    nodes,
                    edges,
                    prefix=f"{path}.else",
                    control_parent=node_id,
                )


def _instruction_expressions(
    instruction: IRInstruction,
) -> tuple[str, ...]:
    if instruction.op == "bind":
        return instruction.arguments[:2]
    if instruction.op in {
        "let",
        "judge",
        "restrict",
        "stabilize",
        "emit",
        "project",
        "if",
    }:
        return instruction.arguments[:1]
    return ()


def _effect_for(operation: str) -> tuple[str, bool]:
    return {
        "let": ("pure", True),
        "if": ("control", True),
        "judge": ("guard", False),
        "restrict": ("guard", False),
        "stabilize": ("evidence", False),
        "project": ("evidence", False),
        "bind": ("evidence", False),
        "emit": ("manifest", False),
    }.get(operation, ("unknown", False))


def _instruction_label(instruction: IRInstruction) -> str:
    arguments = ", ".join(instruction.arguments)
    if instruction.result:
        return f"{instruction.result} = {arguments}"
    return arguments


class _NameCollector(ast.NodeVisitor):
    def __init__(self) -> None:
        self.names: set[str] = set()

    def visit_Name(self, node: ast.Name) -> None:
        self.names.add(node.id)

    def visit_Call(self, node: ast.Call) -> None:
        if not (
            isinstance(node.func, ast.Name)
            and node.func.id in _BUILTINS
        ):
            self.visit(node.func)
        for argument in node.args:
            self.visit(argument)


def _expression_profile(expression: str) -> tuple[tuple[str, ...], int]:
    translated = translate_literals(expression)
    parsed = ast.parse(translated, mode="eval")
    collector = _NameCollector()
    collector.visit(parsed.body)
    cost = 0
    for node in ast.walk(parsed.body):
        if isinstance(
            node,
            (
                ast.BinOp,
                ast.UnaryOp,
                ast.Call,
                ast.IfExp,
            ),
        ):
            cost += 1
        elif isinstance(node, ast.BoolOp):
            cost += max(1, len(node.values) - 1)
        elif isinstance(node, ast.Compare):
            cost += max(1, len(node.ops))
        elif isinstance(node, ast.List):
            cost += len(node.elts)
    return tuple(sorted(collector.names)), cost


def _deduplicate_edges(edges: list[GraphEdge]) -> list[GraphEdge]:
    seen: set[tuple[str, str, str, str | None]] = set()
    result: list[GraphEdge] = []
    for edge in edges:
        key = (edge.source, edge.target, edge.kind, edge.name)
        if key in seen:
            continue
        seen.add(key)
        result.append(edge)
    return result

from __future__ import annotations

from dataclasses import dataclass, field

from .ast import (
    BindStmt,
    CondenseDecl,
    Declaration,
    EmitStmt,
    FieldDecl,
    IfStmt,
    JudgeStmt,
    LetStmt,
    Program,
    ProjectStmt,
    RestrictStmt,
    StabilizeStmt,
    Statement,
    TransitionDecl,
)
from .diagnostics import Diagnostic
from .symbols import Scope, Symbol, SymbolKind, SymbolTable
from .typesys import (
    ANY,
    BOOL,
    SemanticType,
    TypeEngine,
    compatible,
    unify_types,
)


PRIMITIVE_TYPES = frozenset(
    {"Text", "Number", "Bool", "Time", "Date", "Duration", "Any"}
)


@dataclass(slots=True)
class AnalysisResult:
    diagnostics: tuple[Diagnostic, ...]
    symbols: SymbolTable
    operation_outputs: dict[str, SemanticType] = field(default_factory=dict)
    expression_types: dict[str, SemanticType] = field(default_factory=dict)


class LarvaAnalyzer:
    """Resolve símbolos, infere tipos e prova emissão estrutural."""

    def __init__(self) -> None:
        self.type_engine = TypeEngine()

    def analyze(self, program: Program) -> AnalysisResult:
        diagnostics: list[Diagnostic] = []
        symbols = SymbolTable()
        declared: dict[str, Declaration] = {}
        expression_types: dict[str, SemanticType] = {}
        operation_outputs: dict[str, SemanticType] = {}

        if program.module is not None:
            symbols.add(
                symbols.root,
                Symbol(
                    name=program.module.name,
                    qualified_name=program.module.name,
                    kind=SymbolKind.MODULE,
                    type_name=None,
                    scope="<root>",
                    span=program.module.span,
                ),
            )
        for use in program.uses:
            symbols.add(
                symbols.root,
                Symbol(
                    name=use.name,
                    qualified_name=use.name,
                    kind=SymbolKind.USE,
                    type_name=None,
                    scope="<root>",
                    span=use.span,
                ),
            )

        for declaration in program.declarations:
            if declaration.name in declared:
                diagnostics.append(
                    Diagnostic(
                        code="T3001",
                        message=f"declaração duplicada: {declaration.name}",
                        span=declaration.span,
                    )
                )
            else:
                declared[declaration.name] = declaration
                symbols.add(
                    symbols.root,
                    _declaration_symbol(declaration),
                )

        fields = {
            declaration.name: declaration
            for declaration in program.declarations
            if isinstance(declaration, FieldDecl)
        }
        known_types = PRIMITIVE_TYPES | fields.keys()

        for declaration in program.declarations:
            if isinstance(declaration, FieldDecl):
                self._check_field(
                    declaration,
                    known_types,
                    symbols,
                    diagnostics,
                )

        for declaration in program.declarations:
            if isinstance(declaration, CondenseDecl):
                input_field = None
                if declaration.input_type is not None:
                    input_field = fields.get(declaration.input_type)
                    if input_field is None:
                        diagnostics.append(
                            Diagnostic(
                                code="T3002",
                                message=(
                                    f"tipo de entrada desconhecido: "
                                    f"{declaration.input_type}"
                                ),
                                span=declaration.span,
                            )
                        )
                output = self._check_operation(
                    declaration,
                    input_field,
                    known_types,
                    symbols,
                    diagnostics,
                    expression_types,
                )
                operation_outputs[declaration.name] = output
            elif isinstance(declaration, TransitionDecl):
                input_field = fields.get(declaration.from_type)
                for role, type_name in (
                    ("from", declaration.from_type),
                    ("to", declaration.to_type),
                ):
                    if type_name not in fields:
                        diagnostics.append(
                            Diagnostic(
                                code="T3003",
                                message=f"tipo {role} desconhecido: {type_name}",
                                span=declaration.span,
                            )
                        )
                output = self._check_operation(
                    declaration,
                    input_field,
                    known_types,
                    symbols,
                    diagnostics,
                    expression_types,
                )
                operation_outputs[declaration.name] = output

        if not program.declarations and program.span is not None:
            diagnostics.append(
                Diagnostic(
                    code="T3004",
                    message="programa não declara field, condense ou transition",
                    span=program.span,
                )
            )

        return AnalysisResult(
            diagnostics=tuple(diagnostics),
            symbols=symbols,
            operation_outputs=operation_outputs,
            expression_types=expression_types,
        )

    def _check_field(
        self,
        declaration: FieldDecl,
        known_types: set[str] | frozenset[str],
        symbols: SymbolTable,
        diagnostics: list[Diagnostic],
    ) -> None:
        field_scope = symbols.root.child(f"field:{declaration.name}")
        names: set[str] = set()
        for trace in declaration.traces:
            if trace.name in names:
                diagnostics.append(
                    Diagnostic(
                        code="T3010",
                        message=(
                            f"trace duplicado em {declaration.name}: "
                            f"{trace.name}"
                        ),
                        span=trace.span,
                    )
                )
            names.add(trace.name)
            if trace.type_ref.name not in known_types:
                diagnostics.append(
                    Diagnostic(
                        code="T3011",
                        message=f"tipo desconhecido: {trace.type_ref.name}",
                        span=trace.span,
                    )
                )
            symbols.add(
                field_scope,
                Symbol(
                    name=trace.name,
                    qualified_name=f"{declaration.name}.{trace.name}",
                    kind=SymbolKind.TRACE,
                    type_name=SemanticType.from_ref(trace.type_ref).render(),
                    scope=field_scope.name,
                    span=trace.span,
                ),
            )

    def _check_operation(
        self,
        declaration: CondenseDecl | TransitionDecl,
        input_field: FieldDecl | None,
        known_types: set[str] | frozenset[str],
        symbols: SymbolTable,
        diagnostics: list[Diagnostic],
        expression_types: dict[str, SemanticType],
    ) -> SemanticType:
        operation_scope = symbols.root.child(f"operation:{declaration.name}")
        if input_field is not None:
            for trace in input_field.traces:
                symbols.add(
                    operation_scope,
                    Symbol(
                        name=trace.name,
                        qualified_name=f"{declaration.name}.{trace.name}",
                        kind=SymbolKind.TRACE,
                        type_name=SemanticType.from_ref(trace.type_ref).render(),
                        scope=operation_scope.name,
                        span=trace.span,
                    ),
                )

        emit_types: list[SemanticType] = []
        self._check_block(
            declaration.body,
            operation_scope,
            declaration.name,
            known_types,
            symbols,
            diagnostics,
            expression_types,
            emit_types,
        )

        if not _guarantees_emit(declaration.body):
            diagnostics.append(
                Diagnostic(
                    code="T3020",
                    message=f"{declaration.name} não emite em todos os caminhos",
                    span=declaration.span,
                    hint="adicione emit após a decisão ou em ambos os ramos",
                )
            )

        if not emit_types:
            return ANY
        first_output = emit_types[0]
        if any(
            not (
                compatible(first_output, item)
                and compatible(item, first_output)
            )
            for item in emit_types[1:]
        ):
            diagnostics.append(
                Diagnostic(
                    code="T3034",
                    message=(
                        f"{declaration.name} emite tipos incompatíveis: "
                        + ", ".join(sorted({item.render() for item in emit_types}))
                    ),
                    span=declaration.span,
                )
            )
            return ANY
        return unify_types(emit_types)

    def _check_block(
        self,
        body: tuple[Statement, ...],
        scope: Scope,
        operation_name: str,
        known_types: set[str] | frozenset[str],
        symbols: SymbolTable,
        diagnostics: list[Diagnostic],
        expression_types: dict[str, SemanticType],
        emit_types: list[SemanticType],
    ) -> None:
        for statement in body:
            if isinstance(statement, LetStmt):
                inferred = self._infer(
                    statement.value,
                    scope,
                    diagnostics,
                    expression_types,
                )
                if scope.resolve(statement.name) is not None:
                    diagnostics.append(
                        Diagnostic(
                            code="T3031",
                            message=f"nome já definido no escopo: {statement.name}",
                            span=statement.span,
                        )
                    )
                else:
                    symbols.add(
                        scope,
                        Symbol(
                            name=statement.name,
                            qualified_name=f"{operation_name}.{statement.name}",
                            kind=SymbolKind.LOCAL,
                            type_name=inferred.render(),
                            scope=scope.name,
                            span=statement.span,
                        ),
                    )
                continue

            if isinstance(statement, (JudgeStmt, RestrictStmt)):
                condition = self._infer(
                    statement.condition,
                    scope,
                    diagnostics,
                    expression_types,
                )
                self._require_bool(
                    condition,
                    statement.condition,
                    diagnostics,
                )
                continue

            if isinstance(statement, StabilizeStmt):
                self._infer(
                    statement.target,
                    scope,
                    diagnostics,
                    expression_types,
                )
                continue

            if isinstance(statement, EmitStmt):
                emit_types.append(
                    self._infer(
                        statement.value,
                        scope,
                        diagnostics,
                        expression_types,
                    )
                )
                continue

            if isinstance(statement, ProjectStmt):
                self._infer(
                    statement.source,
                    scope,
                    diagnostics,
                    expression_types,
                )
                if statement.target and statement.target not in known_types:
                    diagnostics.append(
                        Diagnostic(
                            code="T3039",
                            message=(
                                f"tipo de projeção desconhecido: "
                                f"{statement.target}"
                            ),
                            span=statement.span,
                        )
                    )
                continue

            if isinstance(statement, BindStmt):
                self._infer(
                    statement.left,
                    scope,
                    diagnostics,
                    expression_types,
                )
                self._infer(
                    statement.right,
                    scope,
                    diagnostics,
                    expression_types,
                )
                continue

            if isinstance(statement, IfStmt):
                condition = self._infer(
                    statement.condition,
                    scope,
                    diagnostics,
                    expression_types,
                )
                self._require_bool(
                    condition,
                    statement.condition,
                    diagnostics,
                )
                then_scope = scope.child(
                    f"{scope.name}/if:{statement.span.line}:then"
                )
                self._check_block(
                    statement.then_body,
                    then_scope,
                    operation_name,
                    known_types,
                    symbols,
                    diagnostics,
                    expression_types,
                    emit_types,
                )
                if statement.else_body:
                    else_scope = scope.child(
                        f"{scope.name}/if:{statement.span.line}:else"
                    )
                    self._check_block(
                        statement.else_body,
                        else_scope,
                        operation_name,
                        known_types,
                        symbols,
                        diagnostics,
                        expression_types,
                        emit_types,
                    )

    def _infer(
        self,
        expression,
        scope: Scope,
        diagnostics: list[Diagnostic],
        expression_types: dict[str, SemanticType],
    ) -> SemanticType:
        result = self.type_engine.infer(expression, scope)
        diagnostics.extend(result.diagnostics)
        expression_types[expression_key(expression)] = result.type
        return result.type

    @staticmethod
    def _require_bool(
        actual: SemanticType,
        expression,
        diagnostics: list[Diagnostic],
    ) -> None:
        if compatible(actual, BOOL):
            return
        diagnostics.append(
            Diagnostic(
                code="T3032",
                message=(
                    f"condição precisa ser Bool, recebido {actual.render()}"
                ),
                span=expression.span,
            )
        )


def _declaration_symbol(declaration: Declaration) -> Symbol:
    if isinstance(declaration, FieldDecl):
        kind = SymbolKind.FIELD
        type_name = declaration.name
    elif isinstance(declaration, CondenseDecl):
        kind = SymbolKind.CONDENSE
        type_name = declaration.input_type
    else:
        kind = SymbolKind.TRANSITION
        type_name = f"{declaration.from_type}->{declaration.to_type}"
    return Symbol(
        name=declaration.name,
        qualified_name=declaration.name,
        kind=kind,
        type_name=type_name,
        scope="<root>",
        span=declaration.span,
    )


def _guarantees_emit(body: tuple[Statement, ...]) -> bool:
    for statement in body:
        if isinstance(statement, EmitStmt):
            return True
        if (
            isinstance(statement, IfStmt)
            and statement.else_body
            and _guarantees_emit(statement.then_body)
            and _guarantees_emit(statement.else_body)
        ):
            return True
    return False


def expression_key(expression) -> str:
    return (
        f"{expression.span.file}:{expression.span.line}:"
        f"{expression.span.column}:{expression.text}"
    )

from __future__ import annotations

import argparse
import json
import platform
import sys
from pathlib import Path
from typing import Sequence

from . import __version__
from .adaptativo import AdaptiveError, run_adaptive_artifact
from .api import check_file
from .artifact import (
    ArtifactBuilder,
    ArtifactError,
    CompilationFailed,
)
from .ast import ast_to_dict
from .backend import BackendError
from .benchmark import BenchmarkError, benchmark_artifact
from .borboleta import (
    BorboletaConfig,
    BorboletaError,
    BorboletaLaboratorio,
    generate_hydrological_dataset,
)
from .native import NativeError, compile_native_artifact, run_native_artifact
from .native_benchmark import (
    NativeBenchmarkError,
    benchmark_native_artifact,
)
from .runner import ExecutionFailed, run_artifact
from .simd_benchmark import SimdBenchmarkError, benchmark_simd_artifact


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="t",
        description="Compilador aberto da linguagem T para o Casulo.",
    )
    parser.add_argument("--version", action="version", version=f"T {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)

    check = commands.add_parser("check", help="Verifica sintaxe e semântica.")
    check.add_argument("source", type=Path)
    check.add_argument("--format", choices=("text", "json"), default="text")

    inspect = commands.add_parser(
        "inspect",
        help="Exibe AST, símbolos ou CrisálidaIR.",
    )
    inspect.add_argument("source", type=Path)
    mode = inspect.add_mutually_exclusive_group()
    mode.add_argument("--ast", action="store_true", help="Exibe a AST.")
    mode.add_argument(
        "--symbols",
        action="store_true",
        help="Exibe a tabela de símbolos.",
    )
    mode.add_argument(
        "--ir",
        action="store_true",
        help="Exibe a CrisálidaIR.",
    )
    mode.add_argument(
        "--graph",
        action="store_true",
        help="Exibe o grafo def-use da Metamorfose.",
    )
    inspect.add_argument("--format", choices=("json", "text"))

    build = commands.add_parser(
        "build",
        help="Materializa um artefato Python reproduzível.",
    )
    build.add_argument("source", type=Path)
    build.add_argument("--output", type=Path)
    build.add_argument("--native", action="store_true")
    build.add_argument("--format", choices=("text", "json"), default="text")

    run = commands.add_parser(
        "run",
        help="Executa uma fonte T ou um artefato Crisálida.",
    )
    run.add_argument("target", type=Path)
    run.add_argument("--operation")
    run.add_argument(
        "--batch",
        action="store_true",
        help="Exige uma lista JSON e executa o kernel de lote.",
    )
    run.add_argument(
        "--no-cache",
        action="store_true",
        help="Desativa memoização por operação nesta execução.",
    )
    run.add_argument(
        "--adaptive",
        action="store_true",
        help="A Crisálida escolhe recalcular ou deduplicar o lote.",
    )
    run.add_argument("--native", action="store_true")
    run.add_argument("--native-required", action="store_true")
    run.add_argument(
        "--memory-budget-mb",
        type=int,
        default=64,
        help="Orçamento de cache para a decisão adaptativa.",
    )
    payload = run.add_mutually_exclusive_group()
    payload.add_argument(
        "--input",
        help="Arquivo JSON de entrada; use - para stdin.",
    )
    payload.add_argument("--data", help="Objeto JSON informado na linha de comando.")
    run.add_argument(
        "--build-dir",
        type=Path,
        help="Destino do build implícito quando target é uma fonte .t.",
    )
    run.add_argument("--format", choices=("json", "text"), default="json")

    benchmark = commands.add_parser(
        "benchmark",
        help="Compara execução escalar e lote fundido.",
    )
    benchmark.add_argument("target", type=Path)
    benchmark.add_argument("--operation")
    benchmark_input = benchmark.add_mutually_exclusive_group(required=True)
    benchmark_input.add_argument("--input")
    benchmark_input.add_argument("--data")
    benchmark.add_argument("--repeat", type=int, default=1)
    benchmark.add_argument("--samples", type=int, default=5)
    benchmark.add_argument("--iterations", type=int, default=10)
    benchmark.add_argument("--output", type=Path)
    benchmark.add_argument("--build-dir", type=Path)

    native_benchmark = commands.add_parser(
        "native-benchmark",
        help="Compara Python escalar e o artefato C99.",
    )
    native_benchmark.add_argument("target", type=Path)
    native_benchmark.add_argument("--operation")
    native_input = native_benchmark.add_mutually_exclusive_group(required=True)
    native_input.add_argument("--input")
    native_input.add_argument("--data")
    native_benchmark.add_argument("--repeat", type=int, default=1)
    native_benchmark.add_argument("--samples", type=int, default=7)
    native_benchmark.add_argument("--iterations", type=int, default=5)
    native_benchmark.add_argument("--output", type=Path)
    native_benchmark.add_argument("--build-dir", type=Path)

    simd_benchmark = commands.add_parser(
        "simd-benchmark",
        help="Compara o kernel C99 escalar estrito com SIMD da máquina.",
    )
    simd_benchmark.add_argument("target", type=Path)
    simd_benchmark.add_argument("--operation")
    simd_input = simd_benchmark.add_mutually_exclusive_group(required=True)
    simd_input.add_argument("--input")
    simd_input.add_argument("--data")
    simd_benchmark.add_argument("--repeat", type=int, default=1)
    simd_benchmark.add_argument("--samples", type=int, default=9)
    simd_benchmark.add_argument("--iterations", type=int, default=2_000)
    simd_benchmark.add_argument("--output", type=Path)
    simd_benchmark.add_argument("--build-dir", type=Path)

    experiment = commands.add_parser(
        "experiment",
        help="Produz evidência Borboleta reproduzível em JSON e HTML.",
    )
    experiment.add_argument("target", type=Path)
    experiment.add_argument("--operation")
    experiment.add_argument("--output", type=Path, required=True)
    experiment.add_argument("--records", type=int, default=2_000)
    experiment.add_argument("--samples", type=int, default=9)
    experiment.add_argument("--iterations", type=int, default=5)
    experiment.add_argument("--warmups", type=int, default=2)
    experiment.add_argument("--seed", type=int, default=24_052_024)
    experiment.add_argument("--duplicate-rate", type=float, default=0.35)
    experiment.add_argument("--bootstrap-resamples", type=int, default=2_000)
    experiment.add_argument("--build-dir", type=Path)

    commands.add_parser("doctor", help="Verifica o frontend instalado.")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "doctor":
        print(f"T compiler: {__version__}")
        print(f"Python: {platform.python_version()}")
        print("Frontend Ovo: disponível")
        print("Análise Larva: disponível")
        print("Tabela de símbolos: disponível")
        print("CrisálidaIR: disponível")
        print("Backend Python de referência: disponível")
        print("ABI nativa e backend C99: disponível")
        print("Perfil SIMD estrito e relatório vetorial: disponível")
        print("Build reproduzível e chave estrutural tipada: disponível")
        print("Executor de artefatos: disponível")
        print("Grafo def-use da Metamorfose: disponível")
        print("Lote fundido e cache local por operação: disponível")
        print("Buffers tipados e evidência lateral: disponível")
        print("Benchmark de velocidade e proxy de CPU: disponível")
        print("Laboratório Borboleta e relatório científico: disponível")
        print("Seletor adaptativo Crisálida: disponível")
        return 0

    try:
        if args.command == "simd-benchmark":
            target = args.target.expanduser().resolve()
            if target.suffix.lower() == ".t":
                built = ArtifactBuilder().build(target, args.build_dir)
                artifact_dir = built.output_dir
            else:
                artifact_dir = target
            raw_payload = _read_json_input(args.input, args.data)
            if args.repeat < 1:
                raise SimdBenchmarkError("repeat precisa ser positivo")
            payloads = (
                raw_payload * args.repeat
                if isinstance(raw_payload, list)
                else [raw_payload] * args.repeat
            )
            report = benchmark_simd_artifact(
                artifact_dir,
                payloads,
                operation=args.operation,
                samples=args.samples,
                iterations=args.iterations,
            )
            rendered = json.dumps(
                report.to_dict(),
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            if args.output is not None:
                output = args.output.expanduser().resolve()
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(rendered + "\n", encoding="utf-8")
            print(rendered)
            return 0

        if args.command == "native-benchmark":
            target = args.target.expanduser().resolve()
            if target.suffix.lower() == ".t":
                built = ArtifactBuilder().build(target, args.build_dir)
                artifact_dir = built.output_dir
            else:
                artifact_dir = target
            raw_payload = _read_json_input(args.input, args.data)
            if args.repeat < 1:
                raise NativeBenchmarkError("repeat precisa ser positivo")
            payloads = (
                raw_payload * args.repeat
                if isinstance(raw_payload, list)
                else [raw_payload] * args.repeat
            )
            report = benchmark_native_artifact(
                artifact_dir,
                payloads,
                operation=args.operation,
                samples=args.samples,
                iterations=args.iterations,
            )
            rendered = json.dumps(
                report.to_dict(),
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            if args.output is not None:
                output = args.output.expanduser().resolve()
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(rendered + "\n", encoding="utf-8")
            print(rendered)
            return 0

        if args.command == "experiment":
            target = args.target.expanduser().resolve()
            if target.suffix.lower() == ".t":
                try:
                    built = ArtifactBuilder().build(target, args.build_dir)
                except CompilationFailed as exc:
                    for diagnostic in exc.diagnostics:
                        print(diagnostic.render(), file=sys.stderr)
                    return 1
                artifact_dir = built.output_dir
            else:
                artifact_dir = target
            config = BorboletaConfig(
                records=args.records,
                samples=args.samples,
                iterations=args.iterations,
                warmups=args.warmups,
                seed=args.seed,
                duplicate_rate=args.duplicate_rate,
                bootstrap_resamples=args.bootstrap_resamples,
            )
            dataset = generate_hydrological_dataset(config)
            report = BorboletaLaboratorio().run(
                artifact_dir,
                operation=args.operation,
                config=config,
                dataset=dataset,
            )
            output = args.output.expanduser().resolve()
            output.mkdir(parents=True, exist_ok=True)
            (output / "dataset.json").write_text(
                json.dumps(
                    list(dataset.payloads),
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                )
                + "\n",
                encoding="utf-8",
            )
            (output / "dataset-manifest.json").write_text(
                json.dumps(
                    dataset.manifest(),
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                )
                + "\n",
                encoding="utf-8",
            )
            json_path, html_path = report.write(output)
            print(
                json.dumps(
                    {
                        "ok": True,
                        "artifact_id": report.artifact_id,
                        "dataset_sha256": dataset.sha256,
                        "report_json": str(json_path),
                        "report_html": str(html_path),
                        "wall_speedup_median": report.comparison[
                            "wall_speedup_median"
                        ],
                        "electrical_energy_measured": report.energy[
                            "electrical_energy_measured"
                        ],
                        "adaptive_strategy": report.adaptation["decision"][
                            "strategy"
                        ],
                        "adaptive_prediction_correct": report.adaptation[
                            "prediction_correct"
                        ],
                    },
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                )
            )
            return 0

        if args.command == "benchmark":
            target = args.target.expanduser().resolve()
            if target.suffix.lower() == ".t":
                try:
                    built = ArtifactBuilder().build(
                        target,
                        args.build_dir,
                    )
                except CompilationFailed as exc:
                    for diagnostic in exc.diagnostics:
                        print(diagnostic.render(), file=sys.stderr)
                    return 1
                artifact_dir = built.output_dir
            else:
                artifact_dir = target
            raw_payload = _read_json_input(args.input, args.data)
            if args.repeat < 1:
                raise BenchmarkError("repeat precisa ser positivo")
            payloads = (
                raw_payload * args.repeat
                if isinstance(raw_payload, list)
                else [raw_payload] * args.repeat
            )
            report = benchmark_artifact(
                artifact_dir,
                payloads,
                operation=args.operation,
                samples=args.samples,
                iterations=args.iterations,
            )
            rendered = json.dumps(
                report.to_dict(),
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            if args.output is not None:
                output = args.output.expanduser().resolve()
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(rendered + "\n", encoding="utf-8")
            print(rendered)
            return 0

        if args.command == "build":
            try:
                built = ArtifactBuilder().build(args.source, args.output)
            except CompilationFailed as exc:
                if args.format == "json":
                    print(
                        json.dumps(
                            {
                                "ok": False,
                                "diagnostics": [
                                    diagnostic.to_dict()
                                    for diagnostic in exc.diagnostics
                                ],
                            },
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
                else:
                    for diagnostic in exc.diagnostics:
                        print(diagnostic.render(), file=sys.stderr)
                return 1
            payload = {
                "artifact_id": built.artifact_id,
                "cache_hit": built.cache_hit,
                "ok": True,
                "output": str(built.output_dir),
            }
            if args.native:
                payload["native"] = compile_native_artifact(
                    built.output_dir
                ).to_dict()
            if args.format == "json":
                print(
                    json.dumps(
                        payload,
                        ensure_ascii=False,
                        indent=2,
                        sort_keys=True,
                    )
                )
            else:
                state = "cache hit" if built.cache_hit else "criado"
                print(f"build: {state}: {built.output_dir}")
                print(f"artifact: {built.artifact_id}")
            return 0

        if args.command == "run":
            target = args.target.expanduser().resolve()
            if target.suffix.lower() == ".t":
                try:
                    built = ArtifactBuilder().build(
                        target,
                        args.build_dir,
                    )
                except CompilationFailed as exc:
                    for diagnostic in exc.diagnostics:
                        print(diagnostic.render(), file=sys.stderr)
                    return 1
                artifact_dir = built.output_dir
            else:
                artifact_dir = target
            input_payload = _read_json_input(args.input, args.data)
            if args.native_required:
                args.native = True
            if args.native and args.adaptive:
                raise AdaptiveError(
                    "--native e --adaptive são mutuamente exclusivos"
                )
            if args.adaptive:
                if args.no_cache:
                    raise AdaptiveError(
                        "--adaptive e --no-cache são mutuamente exclusivos"
                    )
                if not isinstance(input_payload, list):
                    raise AdaptiveError(
                        "--adaptive exige uma lista JSON de entrada"
                    )
                if args.memory_budget_mb < 1:
                    raise AdaptiveError(
                        "--memory-budget-mb precisa ser positivo"
                    )
                adaptive = run_adaptive_artifact(
                    artifact_dir,
                    input_payload,
                    operation=args.operation,
                    memory_budget_bytes=args.memory_budget_mb * 1024 * 1024,
                )
                executed_payload = adaptive.payload
                is_batch = True
            elif args.native:
                native_executed = run_native_artifact(
                    artifact_dir,
                    input_payload,
                    operation=args.operation,
                    batch=True if args.batch else None,
                    fallback=not args.native_required,
                )
                executed_payload = native_executed.payload
                is_batch = native_executed.batch
                if native_executed.fallback_reason is not None:
                    print(
                        "t: fallback Python: "
                        + native_executed.fallback_reason,
                        file=sys.stderr,
                    )
            else:
                executed = run_artifact(
                    artifact_dir,
                    input_payload,
                    operation=args.operation,
                    batch=True if args.batch else None,
                    use_cache=not args.no_cache,
                )
                executed_payload = executed.payload
                is_batch = executed.batch
            if args.format == "text":
                print(
                    json.dumps(
                        (
                            executed_payload["items"]
                            if is_batch
                            else executed_payload["result"]
                        ),
                        ensure_ascii=False,
                        sort_keys=True,
                    )
                )
            else:
                print(
                    json.dumps(
                        executed_payload,
                        ensure_ascii=False,
                        indent=2,
                        sort_keys=True,
                    )
                )
            return 0

        if args.command == "check":
            result = check_file(args.source)
            if args.format == "json":
                print(
                    json.dumps(
                        {
                            "ok": result.ok,
                            "diagnostics": [
                                diagnostic.to_dict()
                                for diagnostic in result.diagnostics
                            ],
                        },
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            elif result.diagnostics:
                for diagnostic in result.diagnostics:
                    print(diagnostic.render(), file=sys.stderr)
            else:
                print(f"{args.source}: ok")
            return 0 if result.ok else 1

        if args.command == "inspect":
            result = check_file(args.source)
            selected = (
                "symbols"
                if args.symbols
                else "graph"
                if args.graph
                else "ir"
                if args.ir
                else "ast"
            )
            output_format = args.format or (
                "text" if selected in {"ir", "graph"} else "json"
            )
            diagnostics = [
                diagnostic.to_dict()
                for diagnostic in result.diagnostics
            ]
            if selected == "symbols":
                if output_format == "text":
                    print(
                        result.symbols.render_text()
                        if result.symbols is not None
                        else ""
                    )
                else:
                    print(
                        json.dumps(
                            {
                                "symbols": (
                                    result.symbols.to_dict()["symbols"]
                                    if result.symbols is not None
                                    else []
                                ),
                                "diagnostics": diagnostics,
                            },
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
            elif selected == "graph":
                if result.graph is None:
                    print(
                        json.dumps(
                            {"graph": None, "diagnostics": diagnostics},
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
                elif output_format == "text":
                    print(result.graph.render_text(), end="")
                else:
                    print(
                        json.dumps(
                            {
                                "graph": result.graph.to_dict(),
                                "diagnostics": diagnostics,
                            },
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
            elif selected == "ir":
                if result.ir is None:
                    print(
                        json.dumps(
                            {"ir": None, "diagnostics": diagnostics},
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
                elif output_format == "text":
                    print(result.ir.render_text(), end="")
                else:
                    print(
                        json.dumps(
                            {
                                "ir": result.ir.to_dict(),
                                "diagnostics": diagnostics,
                            },
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
            else:
                print(
                    json.dumps(
                        {
                            "ast": ast_to_dict(result.program),
                            "diagnostics": diagnostics,
                        },
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            return 0 if result.ok else 1
    except (ArtifactError, BackendError) as exc:
        print(f"t: erro de artefato: {exc}", file=sys.stderr)
        return 2
    except BenchmarkError as exc:
        print(f"t: benchmark inválido: {exc}", file=sys.stderr)
        return 2
    except NativeBenchmarkError as exc:
        print(f"t: benchmark nativo inválido: {exc}", file=sys.stderr)
        return 2
    except SimdBenchmarkError as exc:
        print(f"t: benchmark SIMD inválido: {exc}", file=sys.stderr)
        return 2
    except NativeError as exc:
        print(f"t: execução nativa bloqueada: {exc}", file=sys.stderr)
        return 3
    except BorboletaError as exc:
        print(f"t: experimento Borboleta inválido: {exc}", file=sys.stderr)
        return 2
    except AdaptiveError as exc:
        print(f"t: decisão adaptativa inválida: {exc}", file=sys.stderr)
        return 2
    except ExecutionFailed as exc:
        print(f"t: execução bloqueada: {exc}", file=sys.stderr)
        return 3
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        print(f"t: erro de entrada: {exc}", file=sys.stderr)
        return 2
    return 2


def _read_json_input(input_path: str | None, inline: str | None):
    if inline is not None:
        return json.loads(inline)
    if input_path == "-":
        return json.load(sys.stdin)
    if input_path is not None:
        return json.loads(
            Path(input_path)
            .expanduser()
            .resolve()
            .read_text(encoding="utf-8")
        )
    return {}


if __name__ == "__main__":
    raise SystemExit(main())

"""Compilador aberto da linguagem T para o Casulo."""

__version__ = "0.11.0-alpha.1"

from .api import CheckResult, check_file, check_source, parse_file, parse_source
from .adaptativo import (
    DecisaoCrisalida,
    EstrategiaMetamorfose,
    ExecucaoMetamorfose,
    MetamorfoseAdaptativa,
    ModeloCrisalida,
    PerfilLarva,
    run_adaptive_artifact,
)
from .artifact import ArtifactBuilder, BuildResult
from .backend import (
    STRUCTURAL_KEY_PROTOCOL,
    TYPED_BUFFER_PROTOCOL,
    GeneratedModule,
    PythonBackend,
)
from .benchmark import BenchmarkReport, benchmark_artifact
from .borboleta import (
    BorboletaConfig,
    BorboletaDataset,
    BorboletaLaboratorio,
    BorboletaReport,
    generate_hydrological_dataset,
)
from .graph import MetamorfoseGraph, MetamorfoseGraphBuilder
from .ir import CrisalidaLowerer, IRProgram
from .native import (
    NATIVE_ABI_PROTOCOL,
    NATIVE_AOT_PROTOCOL,
    NATIVE_ARENA_PROTOCOL,
    NATIVE_BACKEND_VERSION,
    NATIVE_BOUNDARY_AOT_PROTOCOL,
    NATIVE_SIMD_PROTOCOL,
    C99Backend,
    NativeBuild,
    PreparedNativeExecutor,
    NativeRunResult,
    NativeSemanticError,
    compile_native_artifact,
    run_native_artifact,
)
from .native_benchmark import (
    NATIVE_BENCHMARK_PROTOCOL,
    NativeBenchmarkReport,
    benchmark_native_artifact,
)
from .runner import LoadedArtifact, RunResult, load_artifact, run_artifact
from .simd_benchmark import (
    SIMD_BENCHMARK_PROTOCOL,
    SimdBenchmarkReport,
    benchmark_simd_artifact,
)
from .symbols import Symbol, SymbolTable

__all__ = [
    "ArtifactBuilder",
    "BenchmarkReport",
    "BorboletaConfig",
    "BorboletaDataset",
    "BorboletaLaboratorio",
    "BorboletaReport",
    "BuildResult",
    "C99Backend",
    "CheckResult",
    "CrisalidaLowerer",
    "DecisaoCrisalida",
    "EstrategiaMetamorfose",
    "ExecucaoMetamorfose",
    "GeneratedModule",
    "IRProgram",
    "LoadedArtifact",
    "MetamorfoseGraph",
    "MetamorfoseGraphBuilder",
    "MetamorfoseAdaptativa",
    "ModeloCrisalida",
    "NATIVE_ABI_PROTOCOL",
    "NATIVE_AOT_PROTOCOL",
    "NATIVE_ARENA_PROTOCOL",
    "NATIVE_BACKEND_VERSION",
    "NATIVE_BENCHMARK_PROTOCOL",
    "NATIVE_BOUNDARY_AOT_PROTOCOL",
    "NATIVE_SIMD_PROTOCOL",
    "NativeBenchmarkReport",
    "NativeBuild",
    "PreparedNativeExecutor",
    "NativeRunResult",
    "NativeSemanticError",
    "PerfilLarva",
    "PythonBackend",
    "RunResult",
    "SIMD_BENCHMARK_PROTOCOL",
    "SimdBenchmarkReport",
    "Symbol",
    "SymbolTable",
    "STRUCTURAL_KEY_PROTOCOL",
    "TYPED_BUFFER_PROTOCOL",
    "benchmark_artifact",
    "benchmark_native_artifact",
    "benchmark_simd_artifact",
    "check_file",
    "check_source",
    "compile_native_artifact",
    "generate_hydrological_dataset",
    "load_artifact",
    "parse_file",
    "parse_source",
    "run_artifact",
    "run_adaptive_artifact",
    "run_native_artifact",
]

from __future__ import annotations

import ast as python_ast
import io
import tokenize
from dataclasses import dataclass
from typing import Iterable

from .ast import Expression, TypeRef
from .diagnostics import Diagnostic
from .symbols import Scope


@dataclass(frozen=True, slots=True)
class SemanticType:
    name: str
    optional: bool = False
    list_depth: int = 0

    def render(self) -> str:
        value = self.name
        for _ in range(self.list_depth):
            value = f"[{value}]"
        if self.optional:
            value += "?"
        return value

    @classmethod
    def from_ref(cls, type_ref: TypeRef) -> SemanticType:
        return cls(
            name=type_ref.name,
            optional=type_ref.optional,
            list_depth=type_ref.list_depth,
        )


ANY = SemanticType("Any")
BOOL = SemanticType("Bool")
NUMBER = SemanticType("Number")
TEXT = SemanticType("Text")


@dataclass(frozen=True, slots=True)
class ExpressionResult:
    type: SemanticType
    diagnostics: tuple[Diagnostic, ...]
    names: tuple[str, ...]


class TypeEngine:
    BUILTINS = {
        "abs": ((NUMBER,), NUMBER),
        "round": ((NUMBER, NUMBER), NUMBER),
        "sqrt": ((NUMBER,), NUMBER),
        "len": ((ANY,), NUMBER),
        "min": ((ANY,), ANY),
        "max": ((ANY,), ANY),
    }

    def infer(self, expression: Expression, scope: Scope) -> ExpressionResult:
        diagnostics: list[Diagnostic] = []
        names: set[str] = set()
        translated = translate_literals(expression.text)
        try:
            parsed = python_ast.parse(translated, mode="eval")
        except SyntaxError as exc:
            diagnostics.append(
                Diagnostic(
                    code="T3021",
                    message=(
                        f"expressão inválida: {expression.text!r}"
                        + (f" ({exc.msg})" if exc.msg else "")
                    ),
                    span=expression.span,
                )
            )
            return ExpressionResult(ANY, tuple(diagnostics), ())

        inferred = self._infer_node(
            parsed.body,
            expression,
            scope,
            diagnostics,
            names,
        )
        return ExpressionResult(
            inferred,
            tuple(diagnostics),
            tuple(sorted(names)),
        )

    def _infer_node(
        self,
        node: python_ast.AST,
        expression: Expression,
        scope: Scope,
        diagnostics: list[Diagnostic],
        names: set[str],
    ) -> SemanticType:
        if isinstance(node, python_ast.Constant):
            if isinstance(node.value, bool):
                return BOOL
            if isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
                return NUMBER
            if isinstance(node.value, str):
                return TEXT
            if node.value is None:
                return SemanticType("Any", optional=True)
            diagnostics.append(
                Diagnostic(
                    code="T3038",
                    message=(
                        "literal ainda não suportado: "
                        f"{type(node.value).__name__}"
                    ),
                    span=expression.span,
                )
            )
            return ANY

        if isinstance(node, python_ast.Name):
            names.add(node.id)
            symbol = scope.resolve(node.id)
            if symbol is None:
                if node.id in self.BUILTINS:
                    return ANY
                diagnostics.append(
                    Diagnostic(
                        code="T3030",
                        message=f"nome não resolvido: {node.id}",
                        span=expression.span,
                    )
                )
                return ANY
            return parse_rendered_type(symbol.type_name)

        if isinstance(node, python_ast.List):
            if not node.elts:
                return SemanticType("Any", list_depth=1)
            element_types = [
                self._infer_node(
                    item,
                    expression,
                    scope,
                    diagnostics,
                    names,
                )
                for item in node.elts
            ]
            unified = unify_types(element_types)
            return SemanticType(
                unified.name,
                optional=unified.optional,
                list_depth=unified.list_depth + 1,
            )

        if isinstance(node, python_ast.UnaryOp):
            operand = self._infer_node(
                node.operand,
                expression,
                scope,
                diagnostics,
                names,
            )
            if isinstance(node.op, python_ast.Not):
                self._expect(operand, BOOL, expression, diagnostics)
                return BOOL
            if not isinstance(node.op, (python_ast.UAdd, python_ast.USub)):
                diagnostics.append(
                    Diagnostic(
                        code="T3038",
                        message=(
                            "operador unário ainda não suportado: "
                            f"{type(node.op).__name__}"
                        ),
                        span=expression.span,
                    )
                )
                return ANY
            self._expect(operand, NUMBER, expression, diagnostics)
            return NUMBER

        if isinstance(node, python_ast.BoolOp):
            for value in node.values:
                inferred = self._infer_node(
                    value,
                    expression,
                    scope,
                    diagnostics,
                    names,
                )
                self._expect(inferred, BOOL, expression, diagnostics)
            return BOOL

        if isinstance(node, python_ast.BinOp):
            left = self._infer_node(
                node.left,
                expression,
                scope,
                diagnostics,
                names,
            )
            right = self._infer_node(
                node.right,
                expression,
                scope,
                diagnostics,
                names,
            )
            if not isinstance(
                node.op,
                (
                    python_ast.Add,
                    python_ast.Sub,
                    python_ast.Mult,
                    python_ast.Div,
                    python_ast.FloorDiv,
                    python_ast.Mod,
                    python_ast.Pow,
                ),
            ):
                diagnostics.append(
                    Diagnostic(
                        code="T3038",
                        message=(
                            "operador aritmético ainda não suportado: "
                            f"{type(node.op).__name__}"
                        ),
                        span=expression.span,
                    )
                )
                return ANY
            if isinstance(node.op, python_ast.Add) and compatible(left, TEXT) and compatible(right, TEXT):
                return TEXT
            self._expect(left, NUMBER, expression, diagnostics)
            self._expect(right, NUMBER, expression, diagnostics)
            return NUMBER

        if isinstance(node, python_ast.Compare):
            values = [node.left, *node.comparators]
            inferred = [
                self._infer_node(
                    value,
                    expression,
                    scope,
                    diagnostics,
                    names,
                )
                for value in values
            ]
            for left, right in zip(inferred, inferred[1:]):
                if not compatible(left, right):
                    diagnostics.append(
                        Diagnostic(
                            code="T3033",
                            message=(
                                f"comparação entre tipos incompatíveis: "
                                f"{left.render()} e {right.render()}"
                            ),
                            span=expression.span,
                        )
                    )
            for operator in node.ops:
                if not isinstance(
                    operator,
                    (
                        python_ast.Eq,
                        python_ast.NotEq,
                        python_ast.Lt,
                        python_ast.LtE,
                        python_ast.Gt,
                        python_ast.GtE,
                    ),
                ):
                    diagnostics.append(
                        Diagnostic(
                            code="T3038",
                            message=(
                                "comparação ainda não suportada: "
                                f"{type(operator).__name__}"
                            ),
                            span=expression.span,
                        )
                    )
            return BOOL

        if isinstance(node, python_ast.IfExp):
            condition = self._infer_node(
                node.test,
                expression,
                scope,
                diagnostics,
                names,
            )
            self._expect(condition, BOOL, expression, diagnostics)
            body_type = self._infer_node(
                node.body,
                expression,
                scope,
                diagnostics,
                names,
            )
            else_type = self._infer_node(
                node.orelse,
                expression,
                scope,
                diagnostics,
                names,
            )
            return unify_types((body_type, else_type))

        if isinstance(node, python_ast.Call):
            if not isinstance(node.func, python_ast.Name):
                diagnostics.append(
                    Diagnostic(
                        code="T3035",
                        message="somente chamadas de funções conhecidas são aceitas em T 1.0",
                        span=expression.span,
                    )
                )
                return ANY
            function = node.func.id
            names.add(function)
            if node.keywords:
                diagnostics.append(
                    Diagnostic(
                        code="T3038",
                        message="argumentos nomeados ainda não são suportados",
                        span=expression.span,
                    )
                )
            signature = self.BUILTINS.get(function)
            if signature is None:
                diagnostics.append(
                    Diagnostic(
                        code="T3035",
                        message=f"função desconhecida: {function}",
                        span=expression.span,
                    )
                )
                for argument in node.args:
                    self._infer_node(
                        argument,
                        expression,
                        scope,
                        diagnostics,
                        names,
                    )
                return ANY
            expected, result = signature
            arguments = [
                self._infer_node(
                    argument,
                    expression,
                    scope,
                    diagnostics,
                    names,
                )
                for argument in node.args
            ]
            valid_arity = (
                len(arguments) >= 1
                if function in {"min", "max"}
                else (
                    len(expected) - (1 if function == "round" else 0)
                    <= len(arguments)
                    <= len(expected)
                )
            )
            if not valid_arity:
                diagnostics.append(
                    Diagnostic(
                        code="T3036",
                        message=(
                            f"{function} recebeu {len(arguments)} argumento(s); "
                            f"esperado {len(expected)}"
                        ),
                        span=expression.span,
                    )
                )
            for actual, wanted in zip(arguments, expected):
                self._expect(actual, wanted, expression, diagnostics)
            if function in {"min", "max"} and arguments:
                return unify_types(arguments)
            return result

        if isinstance(node, python_ast.Attribute):
            diagnostics.append(
                Diagnostic(
                    code="T3037",
                    message="acesso qualificado ainda não foi resolvido nesta versão",
                    span=expression.span,
                )
            )
            return ANY

        diagnostics.append(
            Diagnostic(
                code="T3038",
                message=(
                    f"expressão ainda não suportada: "
                    f"{type(node).__name__}"
                ),
                span=expression.span,
            )
        )
        return ANY

    @staticmethod
    def _expect(
        actual: SemanticType,
        expected: SemanticType,
        expression: Expression,
        diagnostics: list[Diagnostic],
    ) -> None:
        if compatible(actual, expected):
            return
        diagnostics.append(
            Diagnostic(
                code="T3033",
                message=(
                    f"tipo incompatível: esperado {expected.render()}, "
                    f"recebido {actual.render()}"
                ),
                span=expression.span,
            )
        )


def compatible(left: SemanticType, right: SemanticType) -> bool:
    if left.name == "Any" or right.name == "Any":
        return True
    return (
        left.name == right.name
        and left.list_depth == right.list_depth
        and (right.optional or not left.optional)
    )


def unify_types(types: Iterable[SemanticType]) -> SemanticType:
    items = tuple(types)
    if not items:
        return ANY
    first = items[0]
    if all(compatible(first, item) and compatible(item, first) for item in items[1:]):
        return SemanticType(
            first.name,
            optional=any(item.optional for item in items),
            list_depth=first.list_depth,
        )
    return ANY


def parse_rendered_type(value: str | None) -> SemanticType:
    if not value:
        return ANY
    raw = value.strip()
    optional = raw.endswith("?")
    if optional:
        raw = raw[:-1]
    depth = 0
    while raw.startswith("[") and raw.endswith("]"):
        raw = raw[1:-1]
        depth += 1
    return SemanticType(raw, optional=optional, list_depth=depth)


def translate_literals(text: str) -> str:
    replacements = {
        "true": "True",
        "false": "False",
        "null": "None",
    }
    try:
        tokens = list(tokenize.generate_tokens(io.StringIO(text).readline))
    except (IndentationError, tokenize.TokenError):
        return text
    translated = [
        (
            token._replace(string=replacements[token.string])
            if token.type == tokenize.NAME
            and token.string in replacements
            else token
        )
        for token in tokens
    ]
    return tokenize.untokenize(translated)

# Política de segurança

Não publique vulnerabilidades em uma issue aberta. Envie um relato privado ao
mantenedor do repositório, incluindo versão, impacto, passos mínimos de
reprodução e, quando possível, uma correção sugerida.

Artefatos T são verificados por hash antes da execução, mas ainda são código.
Execute somente artefatos de origem confiável e em ambiente com os privilégios
mínimos necessários. Dados hidrometeorológicos sensíveis e credenciais nunca
devem ser incorporados a fontes, datasets de benchmark ou relatórios.

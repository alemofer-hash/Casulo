# Changelog

## Evidência congelada — 2026-07-30

- demonstração comercial autocontida do ganho ponta a ponta;
- alegação delimitada em `6,095936×`, com IC95% `5,994133×–6,230838×`;
- manifesto canônico e `SHA256SUMS`;
- verificador independente da instalação do pacote;
- documentação de transferência comercial e proteção intelectual;
- resultado preservado sem declarar encerramento do Marco 4.

## 0.11.0-alpha.1 — 2026-07-29

### Marco 4 — SIMD estrito

- formato `casulo-artifact/0.8`;
- backend `c99-simd/0.3`;
- protocolos `casulo-simd/0.1` e `casulo-simd-benchmark/0.1`;
- fase escalar de guardas separada do laço numérico independente;
- ordem do primeiro erro e evidências preservadas;
- ponteiros C99 qualificados com `restrict`;
- perfil escalar com vetorização desativada para controle;
- perfil SIMD específico da CPU, sem `fast-math` ou contração FMA;
- relatório do compilador e alvo incorporados à proveniência da build;
- comando `t simd-benchmark`;
- AVX2 de 256 bits demonstrado no i5-1235U;
- ganho SIMD pareado `1,117×`, IC95% `1,084×–1,135×`, em 2.000 registros;
- ausência de ganho conclusivo documentada entre 1 e 256 registros;
- equivalência exata contra o perfil escalar estrito.

## 0.10.0-alpha.1 — 2026-07-29

### Marco 3 — AOT e arena nativa

- formato `casulo-artifact/0.7`;
- backend `c99-aot/0.2`;
- protocolos `casulo-aot/0.1`, `casulo-native-arena/0.1` e
  `casulo-boundary-aot/0.1`;
- remoção AOT de `let` morto;
- propagação de constantes e aliases seguros;
- arena colunar com crescimento em potência de dois;
- fusão de validação e marshal em uma única passagem;
- marshal e manifestação especializados por esquema;
- medição separada de marshal, kernel C99 e manifestação;
- intervalo pareado bootstrap para o ganho ponta a ponta;
- `5,864×` por razão de medianas e mediana pareada `5,966×`;
- IC95% pareado `5,866×–6,169×`;
- Marco 3 encerrado no kernel e máquina declarados.

## 0.9.0-alpha.1 — 2026-07-29

### Marco 3 — primeiro artefato nativo

- formato `casulo-artifact/0.6`;
- ABI `casulo-native-abi/0.1`;
- backend `c99-reference/0.1`;
- fonte C99 e descritor ABI verificáveis dentro do artefato;
- compilação AOT com GCC, Clang ou MSVC;
- DLL/SO derivada em cache imutável por conteúdo;
- layout colunar `float64` com estado e evidência laterais;
- validação de versão ABI e identidade do artefato na biblioteca;
- fallback Python explícito para forma, tipo ou compilador incompatível;
- comando `t native-benchmark`;
- equivalência semântica contra Python escalar;
- `3,958×` ponta a ponta no i5-1235U;
- binário MinGW reproduzível byte a byte.

## 0.8.0-alpha.1 — 2026-07-29

### Marco 2 — caminho quente sem objetos

- formato `casulo-artifact/0.5`;
- backend `python-reference/0.4.1`;
- protocolo `casulo-typed-buffer/0.1`;
- colunas contíguas `float64` e `int64` para operações numéricas elegíveis;
- índices de registros e flags de evidência em buffers laterais;
- manifestação dos envelopes somente na fronteira;
- fallback conservativo para entradas mistas, irregulares ou incompatíveis;
- estratégia adaptativa `FUSE_TYPED_BATCH`;
- protocolos `casulo-adaptive/0.3`, `casulo-cost-model/0.3` e
  `casulo-borboleta/0.4`;
- prova comparativa de alocações por `tracemalloc`;
- meta de `2×` em tráfego intermediário superada.

## 0.7.0-alpha.1 — 2026-07-29

### Chave estrutural e cache local

- formato `casulo-artifact/0.4`;
- backend `python-reference/0.3.1`;
- chave `casulo-structural-key/0.1`, tipada e independente da ordem de objetos;
- especialização AOT para esquemas numéricos;
- igualdade estrutural completa para resolver colisões de fingerprint;
- cache de lote com vida útil restrita a uma chamada;
- clonador conservativo para valores JSON;
- perfil por concentração de pares coincidentes;
- modelo `casulo-cost-model/0.2` calibrado para a nova fronteira;
- protocolos `casulo-adaptive/0.2` e `casulo-borboleta/0.3`;
- melhoria adaptativa conclusiva em 40% de repetição.

## 0.6.0-alpha.1 — 2026-07-29

### Crisálida adaptativa

- custo, determinismo e cacheabilidade incorporados ao manifesto;
- perfil estrutural exato até 128 itens e amostragem determinística acima disso;
- modelo de custo conservador;
- escolha entre recomputação e deduplicação;
- orçamento de memória;
- comando `t run --adaptive`;
- decisão, confiança e justificativa na saída;
- previsão confrontada com a medição Borboleta.
- medição adaptativa ponta a ponta, incluindo perfil, decisão e execução;
- formato Borboleta `casulo-borboleta/0.2`.

## 0.5.0-beta.1 — 2026-07-29

### Borboleta

- API pública `BorboletaLaboratorio`, `BorboletaConfig` e
  `generate_hydrological_dataset`;
- comando `t experiment`;
- dataset determinístico com semente, versão e SHA-256;
- comparação alternada entre referência escalar e estratégia Casulo;
- equivalência por projeção semântica com exclusão explícita de telemetria;
- mediana, amostras brutas, bootstrap pareado e veredito estatístico;
- tempo, CPU, RSS observada e energia detectável;
- relatórios JSON e HTML autocontido;
- testes gerados por propriedades;
- extras `science` e `dev`;
- CI ampliada e release reproduzível por tag.

### Compatibilidade

A API Borboleta é candidata a estável durante a série 0.5. O formato do
relatório é identificado por `casulo-borboleta/0.1`.

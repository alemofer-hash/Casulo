"""Compilador aberto da linguagem T para o Casulo."""

from .api import CheckResult, check_file, check_source, parse_file, parse_source

__all__ = [
    "CheckResult",
    "check_file",
    "check_source",
    "parse_file",
    "parse_source",
]

__version__ = "0.1.0-alpha.1"

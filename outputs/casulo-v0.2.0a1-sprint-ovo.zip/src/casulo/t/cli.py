from __future__ import annotations

import argparse
import json
import platform
import sys
from pathlib import Path
from typing import Sequence

from . import __version__
from .api import check_file, parse_file
from .ast import ast_to_dict


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="t",
        description="Compilador aberto da linguagem T para o Casulo.",
    )
    parser.add_argument("--version", action="version", version=f"T {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)

    check = commands.add_parser("check", help="Verifica sintaxe e semântica.")
    check.add_argument("source", type=Path)
    check.add_argument("--format", choices=("text", "json"), default="text")

    inspect = commands.add_parser("inspect", help="Exibe a AST do programa.")
    inspect.add_argument("source", type=Path)
    inspect.add_argument("--format", choices=("json",), default="json")

    commands.add_parser("doctor", help="Verifica o frontend instalado.")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "doctor":
        print(f"T compiler: {__version__}")
        print(f"Python: {platform.python_version()}")
        print("Frontend Ovo: disponível")
        print("Análise Larva: disponível")
        print("Backend: ainda não implementado nesta sprint")
        return 0

    try:
        if args.command == "check":
            result = check_file(args.source)
            if args.format == "json":
                print(
                    json.dumps(
                        {
                            "ok": result.ok,
                            "diagnostics": [
                                diagnostic.to_dict()
                                for diagnostic in result.diagnostics
                            ],
                        },
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            elif result.diagnostics:
                for diagnostic in result.diagnostics:
                    print(diagnostic.render(), file=sys.stderr)
            else:
                print(f"{args.source}: ok")
            return 0 if result.ok else 1

        if args.command == "inspect":
            result = parse_file(args.source)
            print(
                json.dumps(
                    {
                        "ast": ast_to_dict(result.program),
                        "diagnostics": [
                            diagnostic.to_dict()
                            for diagnostic in result.diagnostics
                        ],
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0 if result.ok else 1
    except (OSError, UnicodeError) as exc:
        print(f"t: erro de entrada: {exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

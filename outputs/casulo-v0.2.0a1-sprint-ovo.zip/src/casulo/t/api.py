from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .analyzer import LarvaAnalyzer
from .ast import Program
from .diagnostics import Diagnostic
from .lexer import OvoLexer
from .parser import OvoParser


@dataclass(frozen=True, slots=True)
class CheckResult:
    program: Program
    diagnostics: tuple[Diagnostic, ...]

    @property
    def ok(self) -> bool:
        return not any(item.severity.value == "error" for item in self.diagnostics)


def parse_source(source: str, file: str = "<memory>") -> CheckResult:
    lexed = OvoLexer().lex(source, file=file)
    parsed = OvoParser(lexed).parse()
    return CheckResult(parsed.program, parsed.diagnostics)


def parse_file(path: str | Path) -> CheckResult:
    source_path = Path(path).expanduser().resolve()
    return parse_source(
        source_path.read_text(encoding="utf-8"),
        file=str(source_path),
    )


def check_source(source: str, file: str = "<memory>") -> CheckResult:
    parsed = parse_source(source, file=file)
    semantic = LarvaAnalyzer().analyze(parsed.program)
    return CheckResult(
        program=parsed.program,
        diagnostics=tuple((*parsed.diagnostics, *semantic.diagnostics)),
    )


def check_file(path: str | Path) -> CheckResult:
    source_path = Path(path).expanduser().resolve()
    return check_source(
        source_path.read_text(encoding="utf-8"),
        file=str(source_path),
    )

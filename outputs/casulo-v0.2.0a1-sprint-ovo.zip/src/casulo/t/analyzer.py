from __future__ import annotations

import ast as python_ast
import re
from dataclasses import dataclass

from .ast import (
    BindStmt,
    CondenseDecl,
    Declaration,
    EmitStmt,
    FieldDecl,
    IfStmt,
    Program,
    ProjectStmt,
    Statement,
    TransitionDecl,
)
from .diagnostics import Diagnostic


PRIMITIVE_TYPES = frozenset(
    {"Text", "Number", "Bool", "Time", "Date", "Duration", "Any"}
)


@dataclass(frozen=True, slots=True)
class AnalysisResult:
    diagnostics: tuple[Diagnostic, ...]


class LarvaAnalyzer:
    """Primeiro gate semântico da linguagem T 1.0."""

    def analyze(self, program: Program) -> AnalysisResult:
        diagnostics: list[Diagnostic] = []
        declared: dict[str, Declaration] = {}

        for declaration in program.declarations:
            if declaration.name in declared:
                diagnostics.append(
                    Diagnostic(
                        code="T3001",
                        message=f"declaração duplicada: {declaration.name}",
                        span=declaration.span,
                    )
                )
            else:
                declared[declaration.name] = declaration

        fields = {
            declaration.name: declaration
            for declaration in program.declarations
            if isinstance(declaration, FieldDecl)
        }
        known_types = PRIMITIVE_TYPES | fields.keys()

        for declaration in program.declarations:
            if isinstance(declaration, FieldDecl):
                self._check_field(declaration, known_types, diagnostics)
            elif isinstance(declaration, CondenseDecl):
                if (
                    declaration.input_type is not None
                    and declaration.input_type not in fields
                ):
                    diagnostics.append(
                        Diagnostic(
                            code="T3002",
                            message=(
                                f"tipo de entrada desconhecido: "
                                f"{declaration.input_type}"
                            ),
                            span=declaration.span,
                        )
                    )
                self._check_body(declaration.body, declaration, diagnostics)
            elif isinstance(declaration, TransitionDecl):
                for role, type_name in (
                    ("from", declaration.from_type),
                    ("to", declaration.to_type),
                ):
                    if type_name not in fields:
                        diagnostics.append(
                            Diagnostic(
                                code="T3003",
                                message=f"tipo {role} desconhecido: {type_name}",
                                span=declaration.span,
                            )
                        )
                self._check_body(declaration.body, declaration, diagnostics)

        if not program.declarations:
            span = program.span
            if span is not None:
                diagnostics.append(
                    Diagnostic(
                        code="T3004",
                        message="programa não declara field, condense ou transition",
                        span=span,
                    )
                )

        return AnalysisResult(tuple(diagnostics))

    def _check_field(
        self,
        field: FieldDecl,
        known_types: set[str] | frozenset[str],
        diagnostics: list[Diagnostic],
    ) -> None:
        names: set[str] = set()
        for trace in field.traces:
            if trace.name in names:
                diagnostics.append(
                    Diagnostic(
                        code="T3010",
                        message=f"trace duplicado em {field.name}: {trace.name}",
                        span=trace.span,
                    )
                )
            names.add(trace.name)
            if trace.type_ref.name not in known_types:
                diagnostics.append(
                    Diagnostic(
                        code="T3011",
                        message=f"tipo desconhecido: {trace.type_ref.name}",
                        span=trace.span,
                    )
                )

    def _check_body(
        self,
        body: tuple[Statement, ...],
        owner: CondenseDecl | TransitionDecl,
        diagnostics: list[Diagnostic],
    ) -> None:
        if not _contains_emit(body):
            diagnostics.append(
                Diagnostic(
                    code="T3020",
                    message=f"{owner.name} não possui emit em nenhum caminho",
                    span=owner.span,
                    hint="emita o resultado estável ou bloqueie a operação",
                )
            )
        for statement in _walk_statements(body):
            for expression in _statement_expressions(statement):
                if not expression.text:
                    continue
                translated = re.sub(
                    r"\b(true|false|null)\b",
                    lambda match: {
                        "true": "True",
                        "false": "False",
                        "null": "None",
                    }[match.group(1)],
                    expression.text,
                )
                try:
                    python_ast.parse(translated, mode="eval")
                except SyntaxError as exc:
                    diagnostics.append(
                        Diagnostic(
                            code="T3021",
                            message=(
                                f"expressão inválida: {expression.text!r}"
                                + (f" ({exc.msg})" if exc.msg else "")
                            ),
                            span=expression.span,
                        )
                    )


def _contains_emit(body: tuple[Statement, ...]) -> bool:
    return any(isinstance(statement, EmitStmt) for statement in _walk_statements(body))


def _walk_statements(body: tuple[Statement, ...]):
    for statement in body:
        yield statement
        if isinstance(statement, IfStmt):
            yield from _walk_statements(statement.then_body)
            yield from _walk_statements(statement.else_body)


def _statement_expressions(statement: Statement):
    if isinstance(statement, ProjectStmt):
        yield statement.source
        return
    if isinstance(statement, BindStmt):
        yield statement.left
        yield statement.right
        return
    for attribute in ("value", "condition", "target", "expression"):
        expression = getattr(statement, attribute, None)
        if expression is not None:
            yield expression

"""Compilador aberto da linguagem T para o Casulo."""

from .api import CheckResult, check_file, check_source, parse_file, parse_source
from .ir import CrisalidaLowerer, IRProgram
from .symbols import Symbol, SymbolTable

__all__ = [
    "CheckResult",
    "CrisalidaLowerer",
    "IRProgram",
    "Symbol",
    "SymbolTable",
    "check_file",
    "check_source",
    "parse_file",
    "parse_source",
]

__version__ = "0.2.0-alpha.2"

from __future__ import annotations

import argparse
import json
import platform
import sys
from pathlib import Path
from typing import Sequence

from . import __version__
from .api import check_file
from .ast import ast_to_dict


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="t",
        description="Compilador aberto da linguagem T para o Casulo.",
    )
    parser.add_argument("--version", action="version", version=f"T {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)

    check = commands.add_parser("check", help="Verifica sintaxe e semântica.")
    check.add_argument("source", type=Path)
    check.add_argument("--format", choices=("text", "json"), default="text")

    inspect = commands.add_parser(
        "inspect",
        help="Exibe AST, símbolos ou CrisálidaIR.",
    )
    inspect.add_argument("source", type=Path)
    mode = inspect.add_mutually_exclusive_group()
    mode.add_argument("--ast", action="store_true", help="Exibe a AST.")
    mode.add_argument(
        "--symbols",
        action="store_true",
        help="Exibe a tabela de símbolos.",
    )
    mode.add_argument(
        "--ir",
        action="store_true",
        help="Exibe a CrisálidaIR.",
    )
    inspect.add_argument("--format", choices=("json", "text"))

    commands.add_parser("doctor", help="Verifica o frontend instalado.")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "doctor":
        print(f"T compiler: {__version__}")
        print(f"Python: {platform.python_version()}")
        print("Frontend Ovo: disponível")
        print("Análise Larva: disponível")
        print("Tabela de símbolos: disponível")
        print("CrisálidaIR: disponível")
        print("Backend: ainda não implementado nesta sprint")
        return 0

    try:
        if args.command == "check":
            result = check_file(args.source)
            if args.format == "json":
                print(
                    json.dumps(
                        {
                            "ok": result.ok,
                            "diagnostics": [
                                diagnostic.to_dict()
                                for diagnostic in result.diagnostics
                            ],
                        },
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            elif result.diagnostics:
                for diagnostic in result.diagnostics:
                    print(diagnostic.render(), file=sys.stderr)
            else:
                print(f"{args.source}: ok")
            return 0 if result.ok else 1

        if args.command == "inspect":
            result = check_file(args.source)
            selected = (
                "symbols"
                if args.symbols
                else "ir"
                if args.ir
                else "ast"
            )
            output_format = args.format or (
                "text" if selected == "ir" else "json"
            )
            diagnostics = [
                diagnostic.to_dict()
                for diagnostic in result.diagnostics
            ]
            if selected == "symbols":
                if output_format == "text":
                    print(
                        result.symbols.render_text()
                        if result.symbols is not None
                        else ""
                    )
                else:
                    print(
                        json.dumps(
                            {
                                "symbols": (
                                    result.symbols.to_dict()["symbols"]
                                    if result.symbols is not None
                                    else []
                                ),
                                "diagnostics": diagnostics,
                            },
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
            elif selected == "ir":
                if result.ir is None:
                    print(
                        json.dumps(
                            {"ir": None, "diagnostics": diagnostics},
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
                elif output_format == "text":
                    print(result.ir.render_text(), end="")
                else:
                    print(
                        json.dumps(
                            {
                                "ir": result.ir.to_dict(),
                                "diagnostics": diagnostics,
                            },
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
            else:
                print(
                    json.dumps(
                        {
                            "ast": ast_to_dict(result.program),
                            "diagnostics": diagnostics,
                        },
                        ensure_ascii=False,
                        indent=2,
                    )
                )
            return 0 if result.ok else 1
    except (OSError, UnicodeError) as exc:
        print(f"t: erro de entrada: {exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

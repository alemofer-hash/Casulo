from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .artifact import ArtifactError, verify_artifact


class ExecutionFailed(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class RunResult:
    artifact_dir: Path
    artifact_id: str
    operation: str
    payload: dict[str, Any]


def run_artifact(
    artifact_dir: str | Path,
    payload: Any,
    operation: str | None = None,
) -> RunResult:
    directory, manifest = verify_artifact(artifact_dir)
    available = tuple(
        entry["name"]
        for entry in manifest.get("operations", [])
        if isinstance(entry, dict) and isinstance(entry.get("name"), str)
    )
    selected = operation
    if selected is None:
        if len(available) == 1:
            selected = available[0]
        elif not available:
            raise ArtifactError("artefato não possui operações executáveis")
        else:
            raise ArtifactError(
                "artefato possui múltiplas operações; informe --operation"
            )
    if selected not in available:
        raise ArtifactError(
            f"operação desconhecida: {selected}; "
            f"disponíveis: {', '.join(available)}"
        )

    executable = directory / manifest["executable"]["file"]
    namespace: dict[str, Any] = {
        "__file__": str(executable),
        "__name__": "_casulo_compiled_artifact",
        "__package__": None,
    }
    try:
        source = executable.read_text(encoding="utf-8")
        exec(compile(source, str(executable), "exec"), namespace)
        execute = namespace.get("execute")
        if not callable(execute):
            raise ArtifactError("artefato não expõe execute(operation, payload)")
        result = execute(selected, payload)
    except ArtifactError:
        raise
    except Exception as exc:
        raise ExecutionFailed(str(exc)) from exc
    if not isinstance(result, dict):
        raise ExecutionFailed("artefato retornou envelope inválido")
    return RunResult(
        artifact_dir=directory,
        artifact_id=manifest["artifact_id"],
        operation=selected,
        payload=result,
    )

"""Compilador aberto da linguagem T para o Casulo."""

__version__ = "0.3.0-alpha.3"

from .api import CheckResult, check_file, check_source, parse_file, parse_source
from .artifact import ArtifactBuilder, BuildResult
from .backend import GeneratedModule, PythonBackend
from .ir import CrisalidaLowerer, IRProgram
from .runner import RunResult, run_artifact
from .symbols import Symbol, SymbolTable

__all__ = [
    "ArtifactBuilder",
    "BuildResult",
    "CheckResult",
    "CrisalidaLowerer",
    "GeneratedModule",
    "IRProgram",
    "PythonBackend",
    "RunResult",
    "Symbol",
    "SymbolTable",
    "check_file",
    "check_source",
    "parse_file",
    "parse_source",
    "run_artifact",
]

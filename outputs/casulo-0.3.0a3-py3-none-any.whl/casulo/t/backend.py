from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from typing import Any

from .ir import IRInstruction, IROperation, IRProgram


BACKEND_VERSION = "python-reference/0.1"


class BackendError(ValueError):
    """A CrisálidaIR contém algo que este backend não consegue materializar."""


@dataclass(frozen=True, slots=True)
class GeneratedModule:
    backend: str
    source: str


class PythonBackend:
    """Materializa CrisálidaIR como um módulo Python autocontido."""

    def generate(
        self,
        program: IRProgram,
        artifact_id: str,
    ) -> GeneratedModule:
        schemas = {
            field.name: {
                trace.name: trace.type_name
                for trace in field.traces
            }
            for field in program.fields
        }
        operation_schemas = {
            operation.name: {
                "kind": operation.kind,
                "input_type": operation.input_type,
                "target_type": operation.target_type,
                "output_type": operation.output_type,
            }
            for operation in program.operations
        }

        lines = [
            '"""Artefato gerado pelo compilador T da Teloscorp / Casulo."""',
            "",
            "from __future__ import annotations",
            "",
            "import json",
            "import math",
            "import sys",
            "from collections.abc import Mapping",
            "",
            f"ARTIFACT_ID = {_python_literal(artifact_id)}",
            f"BACKEND_VERSION = {_python_literal(BACKEND_VERSION)}",
            f"MODULE = {_python_literal(program.module)}",
            f"FIELD_SCHEMAS = {_python_literal(schemas)}",
            f"OPERATION_SCHEMAS = {_python_literal(operation_schemas)}",
            "",
            "",
            "class CasuloRuntimeError(ValueError):",
            "    pass",
            "",
            "",
            "class CasuloInputError(CasuloRuntimeError):",
            "    pass",
            "",
            "",
            "class CasuloJudgeFailed(CasuloRuntimeError):",
            "    pass",
            "",
            "",
            "class CasuloRestrictionFailed(CasuloRuntimeError):",
            "    pass",
            "",
            "",
            "def _type_parts(type_name):",
            "    optional = type_name.endswith('?')",
            "    if optional:",
            "        type_name = type_name[:-1]",
            "    depth = 0",
            "    while type_name.startswith('[') and type_name.endswith(']'):",
            "        type_name = type_name[1:-1]",
            "        depth += 1",
            "    return type_name, optional, depth",
            "",
            "",
            "def _validate_value(value, type_name, path):",
            "    base, optional, depth = _type_parts(type_name)",
            "    if value is None:",
            "        if optional or base == 'Any':",
            "            return",
            "        raise CasuloInputError(f'{path}: valor obrigatório ausente')",
            "    if depth:",
            "        if not isinstance(value, list):",
            "            raise CasuloInputError(f'{path}: esperado {type_name}')",
            "        nested = '[' * (depth - 1) + base + ']' * (depth - 1)",
            "        for index, item in enumerate(value):",
            "            _validate_value(item, nested, f'{path}[{index}]')",
            "        return",
            "    valid = {",
            "        'Any': lambda item: True,",
            "        'Bool': lambda item: isinstance(item, bool),",
            "        'Number': lambda item: isinstance(item, (int, float))",
            "        and not isinstance(item, bool),",
            "        'Text': lambda item: isinstance(item, str),",
            "        'Time': lambda item: isinstance(item, str),",
            "        'Date': lambda item: isinstance(item, str),",
            "        'Duration': lambda item: (",
            "            isinstance(item, (int, float, str))",
            "            and not isinstance(item, bool)",
            "        ),",
            "    }",
            "    if base in FIELD_SCHEMAS:",
            "        _validate_mapping(value, FIELD_SCHEMAS[base], path)",
            "        return",
            "    predicate = valid.get(base)",
            "    if predicate is None or not predicate(value):",
            "        raise CasuloInputError(f'{path}: esperado {type_name}')",
            "",
            "",
            "def _validate_mapping(value, schema, path):",
            "    if not isinstance(value, Mapping):",
            "        raise CasuloInputError(f'{path}: esperado objeto JSON')",
            "    for name, type_name in schema.items():",
            "        _, optional, _ = _type_parts(type_name)",
            "        if name not in value:",
            "            if optional:",
            "                continue",
            "            raise CasuloInputError(f'{path}.{name}: campo obrigatório ausente')",
            "        _validate_value(value[name], type_name, f'{path}.{name}')",
            "",
            "",
            "def _prepare_input(payload, input_type):",
            "    if payload is None:",
            "        payload = {}",
            "    if not isinstance(payload, Mapping):",
            "        raise CasuloInputError('entrada precisa ser um objeto JSON')",
            "    preserved = dict(payload)",
            "    if input_type is not None:",
            "        schema = FIELD_SCHEMAS.get(input_type)",
            "        if schema is None:",
            "            raise CasuloInputError(f'tipo de entrada desconhecido: {input_type}')",
            "        _validate_mapping(preserved, schema, input_type)",
            "    return preserved",
            "",
            "",
            "def _new_evidence():",
            "    return {",
            "        'judgements': [],",
            "        'restrictions': [],",
            "        'projections': [],",
            "        'bindings': [],",
            "        'stabilized': [],",
            "    }",
            "",
            "",
            "def _emit(operation, original_input, result, state, evidence):",
            "    return {",
            "        'artifact_id': ARTIFACT_ID,",
            "        'module': MODULE,",
            "        'operation': operation,",
            "        'state': state,",
            "        'input': original_input,",
            "        'result': result,",
            "        'evidence': evidence,",
            "    }",
            "",
        ]

        operation_functions: list[tuple[str, str]] = []
        for index, operation in enumerate(program.operations):
            function_name = f"_operation_{index}"
            operation_functions.append((operation.name, function_name))
            lines.extend(
                self._render_operation(operation, function_name, schemas)
            )

        lines.extend(
            [
                "OPERATIONS = {",
                *[
                    f"    {_python_literal(name)}: {function_name},"
                    for name, function_name in operation_functions
                ],
                "}",
                "",
                "",
                "def execute(operation, payload=None):",
                "    function = OPERATIONS.get(operation)",
                "    if function is None:",
                "        available = ', '.join(sorted(OPERATIONS))",
                "        raise CasuloRuntimeError(",
                "            f'operação desconhecida: {operation}; disponíveis: {available}'",
                "        )",
                "    return function(payload)",
                "",
                "",
                "def main(argv=None):",
                "    args = list(sys.argv[1:] if argv is None else argv)",
                "    if not 1 <= len(args) <= 2:",
                "        print(",
                "            'uso: python casulo_artifact.py OPERATION [INPUT.json|-]',",
                "            file=sys.stderr,",
                "        )",
                "        return 2",
                "    operation = args[0]",
                "    input_path = args[1] if len(args) == 2 else None",
                "    try:",
                "        if input_path == '-':",
                "            payload = json.load(sys.stdin)",
                "        elif input_path is None:",
                "            payload = {}",
                "        else:",
                "            with open(input_path, encoding='utf-8') as stream:",
                "                payload = json.load(stream)",
                "    except (OSError, UnicodeError, json.JSONDecodeError) as exc:",
                "        print(f'entrada inválida: {exc}', file=sys.stderr)",
                "        return 2",
                "    try:",
                "        result = execute(operation, payload)",
                "    except CasuloRuntimeError as exc:",
                "        print(f'execução bloqueada: {exc}', file=sys.stderr)",
                "        return 3",
                "    json.dump(",
                "        result,",
                "        sys.stdout,",
                "        ensure_ascii=False,",
                "        indent=2,",
                "        sort_keys=True,",
                "    )",
                "    sys.stdout.write('\\n')",
                "    return 0",
                "",
                "",
                "if __name__ == '__main__':",
                "    raise SystemExit(main())",
                "",
            ]
        )
        return GeneratedModule(
            backend=BACKEND_VERSION,
            source="\n".join(lines),
        )

    def _render_operation(
        self,
        operation: IROperation,
        function_name: str,
        schemas: dict[str, dict[str, str]],
    ) -> list[str]:
        lines = [
            "",
            f"def {function_name}(payload):",
            (
                "    _input = _prepare_input("
                f"payload, {_python_literal(operation.input_type)})"
            ),
            "    _env = dict(_input)",
            "    _evidence = _new_evidence()",
            "    _state = 'partial'",
        ]
        if operation.input_type in schemas:
            for name, type_name in schemas[operation.input_type].items():
                if type_name.endswith("?"):
                    lines.append(
                        f"    _env.setdefault({_python_literal(name)}, None)"
                    )
        lines.extend(
            self._render_block(
                operation.instructions,
                operation,
                depth=1,
            )
        )
        lines.extend(
            [
                "    raise CasuloRuntimeError(",
                f"        {_python_literal(f'operação {operation.name} terminou sem emit')}",
                "    )",
            ]
        )
        return lines

    def _render_block(
        self,
        instructions: tuple[IRInstruction, ...],
        operation: IROperation,
        depth: int,
    ) -> list[str]:
        prefix = "    " * depth
        lines: list[str] = []
        for instruction in instructions:
            args = instruction.arguments
            if instruction.op == "let":
                expression = _render_expression(args[0])
                lines.append(
                    f"{prefix}_env[{_python_literal(instruction.result)}] = "
                    f"{expression}"
                )
                continue
            if instruction.op in {"judge", "restrict"}:
                expression = _render_expression(args[0])
                variable = "_condition"
                exception = (
                    "CasuloJudgeFailed"
                    if instruction.op == "judge"
                    else "CasuloRestrictionFailed"
                )
                evidence_key = (
                    "judgements"
                    if instruction.op == "judge"
                    else "restrictions"
                )
                message = (
                    f"{instruction.op} falhou em {operation.name}: {args[0]}"
                )
                lines.extend(
                    [
                        f"{prefix}{variable} = bool({expression})",
                        f"{prefix}if not {variable}:",
                        f"{prefix}    raise {exception}({_python_literal(message)})",
                        (
                            f"{prefix}_evidence[{_python_literal(evidence_key)}]"
                            ".append({"
                            f"'expression': {_python_literal(args[0])}, "
                            "'passed': True})"
                        ),
                    ]
                )
                continue
            if instruction.op == "stabilize":
                expression = _render_expression(args[0])
                lines.extend(
                    [
                        f"{prefix}_stabilized_value = {expression}",
                        (
                            f"{prefix}_evidence['stabilized'].append({{"
                            f"'expression': {_python_literal(args[0])}, "
                            "'value': _stabilized_value})"
                        ),
                        f"{prefix}_state = 'stable'",
                    ]
                )
                continue
            if instruction.op == "emit":
                expression = _render_expression(args[0])
                lines.append(
                    f"{prefix}return _emit("
                    f"{_python_literal(operation.name)}, _input, "
                    f"{expression}, _state, _evidence)"
                )
                continue
            if instruction.op == "project":
                expression = _render_expression(args[0])
                target = None
                into: list[str] = []
                for argument in args[1:]:
                    if argument.startswith("as:"):
                        target = argument[3:]
                    elif argument.startswith("into:"):
                        into = [
                            item
                            for item in argument[5:].split(",")
                            if item
                        ]
                lines.extend(
                    [
                        f"{prefix}_projected_value = {expression}",
                        (
                            f"{prefix}_evidence['projections'].append({{"
                            f"'expression': {_python_literal(args[0])}, "
                            "'value': _projected_value, "
                            f"'target': {_python_literal(target)}, "
                            f"'into': {_python_literal(into)}}})"
                        ),
                    ]
                )
                continue
            if instruction.op == "bind":
                left = _render_expression(args[0])
                right = _render_expression(args[1])
                lines.append(
                    f"{prefix}_evidence['bindings'].append({{"
                    f"'left_expression': {_python_literal(args[0])}, "
                    f"'left': {left}, "
                    f"'right_expression': {_python_literal(args[1])}, "
                    f"'right': {right}}})"
                )
                continue
            if instruction.op == "if":
                condition = _render_expression(args[0])
                lines.append(f"{prefix}if {condition}:")
                lines.extend(
                    self._render_block(
                        instruction.then_body,
                        operation,
                        depth + 1,
                    )
                    or [f"{prefix}    pass"]
                )
                if instruction.else_body:
                    lines.append(f"{prefix}else:")
                    lines.extend(
                        self._render_block(
                            instruction.else_body,
                            operation,
                            depth + 1,
                        )
                        or [f"{prefix}    pass"]
                    )
                continue
            raise BackendError(f"instrução IR não suportada: {instruction.op}")
        return lines


_LITERAL_PATTERN = re.compile(r"\b(true|false|null)\b")
_BIN_OPS = {
    ast.Add: "+",
    ast.Sub: "-",
    ast.Mult: "*",
    ast.Div: "/",
    ast.FloorDiv: "//",
    ast.Mod: "%",
    ast.Pow: "**",
}
_UNARY_OPS = {
    ast.Not: "not ",
    ast.UAdd: "+",
    ast.USub: "-",
}
_BOOL_OPS = {
    ast.And: "and",
    ast.Or: "or",
}
_COMPARE_OPS = {
    ast.Eq: "==",
    ast.NotEq: "!=",
    ast.Lt: "<",
    ast.LtE: "<=",
    ast.Gt: ">",
    ast.GtE: ">=",
}
_BUILTINS = {
    "abs": "abs",
    "round": "round",
    "sqrt": "math.sqrt",
    "len": "len",
    "min": "min",
    "max": "max",
}


def _render_expression(text: str) -> str:
    translated = _LITERAL_PATTERN.sub(
        lambda match: {
            "true": "True",
            "false": "False",
            "null": "None",
        }[match.group(1)],
        text,
    )
    try:
        expression = ast.parse(translated, mode="eval").body
    except SyntaxError as exc:
        raise BackendError(f"expressão IR inválida: {text!r}") from exc
    return _render_expression_node(expression)


def _render_expression_node(node: ast.AST) -> str:
    if isinstance(node, ast.Constant):
        if node.value is None or isinstance(
            node.value,
            (bool, int, float, str),
        ):
            return repr(node.value)
        raise BackendError(f"literal não suportado: {node.value!r}")
    if isinstance(node, ast.Name):
        return f"_env[{node.id!r}]"
    if isinstance(node, ast.List):
        return "[" + ", ".join(
            _render_expression_node(item)
            for item in node.elts
        ) + "]"
    if isinstance(node, ast.UnaryOp):
        operator = _UNARY_OPS.get(type(node.op))
        if operator is None:
            raise BackendError(
                f"operador unário não suportado: {type(node.op).__name__}"
            )
        return f"({operator}{_render_expression_node(node.operand)})"
    if isinstance(node, ast.BoolOp):
        operator = _BOOL_OPS.get(type(node.op))
        if operator is None:
            raise BackendError(
                f"operador booleano não suportado: {type(node.op).__name__}"
            )
        return "(" + f" {operator} ".join(
            _render_expression_node(item)
            for item in node.values
        ) + ")"
    if isinstance(node, ast.BinOp):
        operator = _BIN_OPS.get(type(node.op))
        if operator is None:
            raise BackendError(
                f"operador aritmético não suportado: {type(node.op).__name__}"
            )
        return (
            f"({_render_expression_node(node.left)} {operator} "
            f"{_render_expression_node(node.right)})"
        )
    if isinstance(node, ast.Compare):
        rendered = [_render_expression_node(node.left)]
        for operator_node, comparator in zip(node.ops, node.comparators):
            operator = _COMPARE_OPS.get(type(operator_node))
            if operator is None:
                raise BackendError(
                    "comparação não suportada: "
                    f"{type(operator_node).__name__}"
                )
            rendered.extend((operator, _render_expression_node(comparator)))
        return "(" + " ".join(rendered) + ")"
    if isinstance(node, ast.IfExp):
        return (
            f"({_render_expression_node(node.body)} if "
            f"{_render_expression_node(node.test)} else "
            f"{_render_expression_node(node.orelse)})"
        )
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
        function = _BUILTINS.get(node.func.id)
        if function is None or node.keywords:
            raise BackendError(f"chamada não suportada: {node.func.id}")
        return (
            f"{function}("
            + ", ".join(_render_expression_node(arg) for arg in node.args)
            + ")"
        )
    raise BackendError(
        f"expressão não suportada pelo backend: {type(node).__name__}"
    )


def _python_literal(value: Any) -> str:
    if value is None or isinstance(value, (bool, int, float, str)):
        return repr(value)
    if isinstance(value, list):
        return "[" + ", ".join(_python_literal(item) for item in value) + "]"
    if isinstance(value, tuple):
        suffix = "," if len(value) == 1 else ""
        return (
            "("
            + ", ".join(_python_literal(item) for item in value)
            + suffix
            + ")"
        )
    if isinstance(value, dict):
        items = ", ".join(
            f"{_python_literal(key)}: {_python_literal(value[key])}"
            for key in sorted(value)
        )
        return "{" + items + "}"
    raise TypeError(f"literal Python não suportado: {type(value)!r}")

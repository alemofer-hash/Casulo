# Backend Python de referência 0.1

**Identificador:** `python-reference/0.1`
**Formato do pacote:** `casulo-artifact/0.1`
**Origem:** Teloscorp / Casulo

## Finalidade

O backend da Crisálida transforma uma CrisálidaIR válida em um módulo Python
determinístico e autocontido. O módulo usa somente a biblioteca padrão do
Python e não depende da IDE nem de uma instalação do pacote Casulo.

## Pipeline

```text
source.t
→ frontend Ovo
→ análise Larva
→ CrisálidaIR canônica
→ backend Python
→ artefato endereçado por conteúdo
```

## Layout do artefato

```text
artefato/
├─ source.t
├─ crisalida.ir.json
├─ casulo_artifact.py
└─ manifest.json
```

- `source.t`: fonte integral recebida pelo compilador;
- `crisalida.ir.json`: significado tipado sem localização física;
- `casulo_artifact.py`: execução autocontida;
- `manifest.json`: hashes, versões, operações, marca e origem.

O manifesto não contém relógio, caminho absoluto ou identificador aleatório.

## Identidade

O identificador é:

```text
sha256(
  formato do artefato
  + versão do compilador
  + versão do backend
  + hash da fonte
  + hash da IR canônica
)
```

Fontes byte a byte idênticas produzem o mesmo identificador,
independentemente do diretório e do nome do arquivo.

## Cache

O segundo build só é considerado cache hit quando:

- o manifesto é idêntico;
- a fonte preservada é idêntica;
- a IR é idêntica;
- o executável é idêntico.

Um diretório existente que não satisfaça essas condições não é sobrescrito.

## Execução

```powershell
t build programa.t --output artefato
t run artefato --operation Operacao --input entrada.json
```

Quando existe uma única operação, `--operation` é opcional. Uma fonte também
pode ser executada diretamente; nesse caso `t run` realiza um build implícito:

```powershell
t run programa.t --input entrada.json
```

O módulo gerado também possui uma CLI própria e não importa o pacote Casulo:

```powershell
python artefato/casulo_artifact.py Operacao entrada.json
```

Essa forma executa o módulo isoladamente. `t run` continua sendo a entrada
recomendada quando se deseja verificar toda a cadeia fonte → IR → executável
antes da execução.

## Validação JSON

Representações de referência:

| Tipo T | JSON/Python |
|---|---|
| `Number` | número, exceto booleano |
| `Bool` | booleano |
| `Text`, `Time`, `Date` | string |
| `Duration` | número ou string |
| `[T]` | lista validada recursivamente |
| `T?` | valor de `T`, `null` ou campo ausente |
| field | objeto com traces obrigatórios |

Campos adicionais são preservados. O backend não os descarta.

## Envelope

Uma emissão retorna:

```json
{
  "artifact_id": "sha256:...",
  "module": "casulo.flood_rs",
  "operation": "WaterBalance",
  "state": "stable",
  "input": {},
  "result": 0,
  "evidence": {
    "judgements": [],
    "restrictions": [],
    "projections": [],
    "bindings": [],
    "stabilized": []
  }
}
```

## Integridade e falhas

Antes de carregar o módulo, `t run`:

1. recalcula os hashes da fonte, da IR e do executável;
2. recompila a fonte preservada;
3. compara novamente a IR canônica;
4. regenera e compara o executável;
5. valida o índice de operações;
6. bloqueia caminhos que escapem do diretório do artefato.

Alterar um arquivo e apenas atualizar seu hash no manifesto não é suficiente
para passar por essa cadeia.

Códigos de saída:

| Código | Significado |
|---|---|
| `0` | build ou execução concluída |
| `1` | fonte T rejeitada por diagnóstico |
| `2` | entrada ou artefato inválido |
| `3` | execução bloqueada por schema, `judge` ou `restrict` |

## Limites conscientes

- um registro é executado por chamada;
- não há vetorização;
- não há paralelismo;
- não há sandbox de código Python;
- não há módulos `use` resolvidos;
- não há backend nativo;
- não há cache incremental abaixo do artefato completo.

"""Compilador aberto da linguagem T para o Casulo."""

__version__ = "0.5.0-beta.1"

from .api import CheckResult, check_file, check_source, parse_file, parse_source
from .artifact import ArtifactBuilder, BuildResult
from .backend import GeneratedModule, PythonBackend
from .benchmark import BenchmarkReport, benchmark_artifact
from .borboleta import (
    BorboletaConfig,
    BorboletaDataset,
    BorboletaLaboratorio,
    BorboletaReport,
    generate_hydrological_dataset,
)
from .graph import MetamorfoseGraph, MetamorfoseGraphBuilder
from .ir import CrisalidaLowerer, IRProgram
from .runner import LoadedArtifact, RunResult, load_artifact, run_artifact
from .symbols import Symbol, SymbolTable

__all__ = [
    "ArtifactBuilder",
    "BenchmarkReport",
    "BorboletaConfig",
    "BorboletaDataset",
    "BorboletaLaboratorio",
    "BorboletaReport",
    "BuildResult",
    "CheckResult",
    "CrisalidaLowerer",
    "GeneratedModule",
    "IRProgram",
    "LoadedArtifact",
    "MetamorfoseGraph",
    "MetamorfoseGraphBuilder",
    "PythonBackend",
    "RunResult",
    "Symbol",
    "SymbolTable",
    "benchmark_artifact",
    "check_file",
    "check_source",
    "generate_hydrological_dataset",
    "load_artifact",
    "parse_file",
    "parse_source",
    "run_artifact",
]

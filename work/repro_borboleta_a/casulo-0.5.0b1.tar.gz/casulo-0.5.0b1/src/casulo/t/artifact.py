from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import __version__ as COMPILER_VERSION
from .api import check_file
from .backend import BACKEND_VERSION, BackendError, PythonBackend
from .diagnostics import Diagnostic
from .ir import IRProgram


ARTIFACT_FORMAT = "casulo-artifact/0.2"
EXECUTABLE_FILE = "casulo_artifact.py"
GRAPH_FILE = "metamorfose.graph.json"
IR_FILE = "crisalida.ir.json"
MANIFEST_FILE = "manifest.json"
SOURCE_FILE = "source.t"


class ArtifactError(RuntimeError):
    pass


class CompilationFailed(ArtifactError):
    def __init__(self, diagnostics: tuple[Diagnostic, ...]) -> None:
        self.diagnostics = diagnostics
        super().__init__("o programa T não passou pelos gates do compilador")


@dataclass(frozen=True, slots=True)
class BuildResult:
    output_dir: Path
    artifact_id: str
    manifest: dict[str, Any]
    cache_hit: bool


class ArtifactBuilder:
    def __init__(self, backend: PythonBackend | None = None) -> None:
        self.backend = backend or PythonBackend()

    def build(
        self,
        source: str | Path,
        output_dir: str | Path | None = None,
    ) -> BuildResult:
        source_path = Path(source).expanduser().resolve()
        source_bytes = source_path.read_bytes()
        checked = check_file(source_path)
        if (
            not checked.ok
            or checked.ir is None
            or checked.graph is None
        ):
            raise CompilationFailed(checked.diagnostics)

        ir_payload = canonical_ir_dict(checked.ir)
        ir_bytes = _canonical_json_bytes(ir_payload)
        graph_bytes = _canonical_json_bytes(checked.graph.to_dict())
        source_hash = _sha256(source_bytes)
        ir_hash = _sha256(ir_bytes)
        graph_hash = _sha256(graph_bytes)
        seed = {
            "artifact_format": ARTIFACT_FORMAT,
            "backend": BACKEND_VERSION,
            "compiler": COMPILER_VERSION,
            "graph_sha256": graph_hash,
            "ir_sha256": ir_hash,
            "source_sha256": source_hash,
        }
        digest = _sha256(_canonical_json_bytes(seed))
        artifact_id = f"sha256:{digest}"
        generated = self.backend.generate(checked.ir, artifact_id)
        executable_bytes = generated.source.encode("utf-8")
        executable_hash = _sha256(executable_bytes)

        manifest = {
            "artifact_format": ARTIFACT_FORMAT,
            "artifact_id": artifact_id,
            "brand": "Casulo",
            "origin": "Teloscorp",
            "compiler": {
                "name": "T",
                "version": COMPILER_VERSION,
            },
            "backend": {
                "name": "Python de referência",
                "version": generated.backend,
            },
            "source": {
                "encoding": "utf-8",
                "file": SOURCE_FILE,
                "sha256": source_hash,
            },
            "ir": {
                "file": IR_FILE,
                "sha256": ir_hash,
                "version": checked.ir.version,
            },
            "graph": {
                "file": GRAPH_FILE,
                "sha256": graph_hash,
                "version": checked.graph.version,
            },
            "executable": {
                "file": EXECUTABLE_FILE,
                "language": "python",
                "requires": ">=3.11",
                "sha256": executable_hash,
            },
            "module": checked.ir.module,
            "operations": [
                {
                    "input_type": operation.input_type,
                    "kind": operation.kind,
                    "name": operation.name,
                    "output_type": operation.output_type,
                    "target_type": operation.target_type,
                }
                for operation in checked.ir.operations
            ],
        }
        manifest_bytes = _canonical_json_bytes(manifest)

        target = (
            Path(output_dir).expanduser().resolve()
            if output_dir is not None
            else (
                source_path.parent
                / ".casulo"
                / "build"
                / digest[:16]
            ).resolve()
        )
        files = {
            SOURCE_FILE: source_bytes,
            IR_FILE: ir_bytes,
            GRAPH_FILE: graph_bytes,
            EXECUTABLE_FILE: executable_bytes,
            MANIFEST_FILE: manifest_bytes,
        }
        if target.exists():
            if _is_valid_cache(target, manifest, files):
                return BuildResult(
                    output_dir=target,
                    artifact_id=artifact_id,
                    manifest=manifest,
                    cache_hit=True,
                )
            raise ArtifactError(
                f"destino já existe e não é o mesmo artefato válido: {target}"
            )

        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = Path(
            tempfile.mkdtemp(
                prefix=f".{target.name}.",
                dir=target.parent,
            )
        )
        try:
            for name, content in files.items():
                (temporary / name).write_bytes(content)
            temporary.rename(target)
        except BaseException:
            if temporary.exists():
                shutil.rmtree(temporary)
            raise

        return BuildResult(
            output_dir=target,
            artifact_id=artifact_id,
            manifest=manifest,
            cache_hit=False,
        )


def canonical_ir_dict(program: IRProgram) -> dict[str, Any]:
    """Remove localização física sem retirar significado executável da IR."""

    return _without_spans(program.to_dict())


def read_manifest(artifact_dir: str | Path) -> dict[str, Any]:
    directory = Path(artifact_dir).expanduser().resolve()
    manifest_path = directory / MANIFEST_FILE
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ArtifactError(
            f"manifesto de artefato inválido: {manifest_path}"
        ) from exc
    if not isinstance(payload, dict):
        raise ArtifactError(
            f"manifesto de artefato precisa ser um objeto: {manifest_path}"
        )
    if payload.get("artifact_format") != ARTIFACT_FORMAT:
        raise ArtifactError(
            f"formato de artefato não suportado: "
            f"{payload.get('artifact_format')!r}"
        )
    return payload


def verify_artifact(
    artifact_dir: str | Path,
) -> tuple[Path, dict[str, Any]]:
    directory = Path(artifact_dir).expanduser().resolve()
    manifest = read_manifest(directory)
    compiler = manifest.get("compiler")
    backend = manifest.get("backend")
    if not isinstance(compiler, dict) or compiler.get("version") != COMPILER_VERSION:
        raise ArtifactError(
            "versão do compilador no artefato não é suportada por este executor"
        )
    if not isinstance(backend, dict) or backend.get("version") != BACKEND_VERSION:
        raise ArtifactError(
            "versão do backend no artefato não é suportada por este executor"
        )
    verified_files: dict[str, tuple[Path, bytes]] = {}
    for section in ("source", "ir", "graph", "executable"):
        entry = manifest.get(section)
        if not isinstance(entry, dict):
            raise ArtifactError(f"seção ausente no manifesto: {section}")
        filename = entry.get("file")
        expected = entry.get("sha256")
        if not isinstance(filename, str) or not isinstance(expected, str):
            raise ArtifactError(f"seção inválida no manifesto: {section}")
        file_path = (directory / filename).resolve()
        if not file_path.is_relative_to(directory):
            raise ArtifactError(
                f"caminho externo bloqueado no manifesto: {filename}"
            )
        try:
            content = file_path.read_bytes()
            actual = _sha256(content)
        except OSError as exc:
            raise ArtifactError(
                f"arquivo ausente no artefato: {file_path}"
            ) from exc
        if actual != expected:
            raise ArtifactError(
                f"integridade violada em {filename}: "
                f"esperado {expected}, recebido {actual}"
            )
        verified_files[section] = (file_path, content)

    expected_id = "sha256:" + _sha256(
        _canonical_json_bytes(
            {
                "artifact_format": ARTIFACT_FORMAT,
                "backend": backend["version"],
                "compiler": compiler["version"],
                "graph_sha256": manifest["graph"]["sha256"],
                "ir_sha256": manifest["ir"]["sha256"],
                "source_sha256": manifest["source"]["sha256"],
            }
        )
    )
    if manifest.get("artifact_id") != expected_id:
        raise ArtifactError(
            "artifact_id não corresponde à fonte, à IR e às versões declaradas"
        )

    source_path, _ = verified_files["source"]
    checked = check_file(source_path)
    if (
        not checked.ok
        or checked.ir is None
        or checked.graph is None
    ):
        raise ArtifactError(
            "fonte preservada não recompila com o compilador declarado"
        )
    expected_ir = _canonical_json_bytes(canonical_ir_dict(checked.ir))
    if verified_files["ir"][1] != expected_ir:
        raise ArtifactError(
            "CrisálidaIR não corresponde à fonte preservada"
        )
    expected_graph = _canonical_json_bytes(checked.graph.to_dict())
    if verified_files["graph"][1] != expected_graph:
        raise ArtifactError(
            "grafo da Metamorfose não corresponde à fonte preservada"
        )
    try:
        expected_executable = PythonBackend().generate(
            checked.ir,
            expected_id,
        ).source.encode("utf-8")
    except BackendError as exc:
        raise ArtifactError(
            "fonte preservada não pode ser regenerada pelo backend declarado"
        ) from exc
    if verified_files["executable"][1] != expected_executable:
        raise ArtifactError(
            "executável não corresponde à fonte e à CrisálidaIR"
        )

    expected_operations = [
        {
            "input_type": operation.input_type,
            "kind": operation.kind,
            "name": operation.name,
            "output_type": operation.output_type,
            "target_type": operation.target_type,
        }
        for operation in checked.ir.operations
    ]
    if (
        manifest.get("module") != checked.ir.module
        or manifest.get("operations") != expected_operations
    ):
        raise ArtifactError(
            "índice de operações do manifesto não corresponde à CrisálidaIR"
        )
    return directory, manifest


def _is_valid_cache(
    directory: Path,
    expected_manifest: dict[str, Any],
    expected_files: dict[str, bytes],
) -> bool:
    try:
        current_manifest = json.loads(
            (directory / MANIFEST_FILE).read_text(encoding="utf-8")
        )
    except (OSError, UnicodeError, json.JSONDecodeError):
        return False
    if current_manifest != expected_manifest:
        return False
    for name, content in expected_files.items():
        try:
            if (directory / name).read_bytes() != content:
                return False
        except OSError:
            return False
    return True


def _without_spans(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            key: _without_spans(item)
            for key, item in value.items()
            if key != "span"
        }
    if isinstance(value, list):
        return [_without_spans(item) for item in value]
    if isinstance(value, tuple):
        return [_without_spans(item) for item in value]
    return value


def _canonical_json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")


def _sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()

# Changelog

## 0.5.0-beta.1 — 2026-07-29

### Borboleta

- API pública `BorboletaLaboratorio`, `BorboletaConfig` e
  `generate_hydrological_dataset`;
- comando `t experiment`;
- dataset determinístico com semente, versão e SHA-256;
- comparação alternada entre referência escalar e estratégia Casulo;
- equivalência por projeção semântica com exclusão explícita de telemetria;
- mediana, amostras brutas, bootstrap pareado e veredito estatístico;
- tempo, CPU, RSS observada e energia detectável;
- relatórios JSON e HTML autocontido;
- testes gerados por propriedades;
- extras `science` e `dev`;
- CI ampliada e release reproduzível por tag.

### Compatibilidade

A API Borboleta é candidata a estável durante a série 0.5. O formato do
relatório é identificado por `casulo-borboleta/0.1`.
